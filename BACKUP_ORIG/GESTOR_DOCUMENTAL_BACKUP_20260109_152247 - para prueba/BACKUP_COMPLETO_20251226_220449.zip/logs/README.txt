=========================================================================
DIRECTORIO DE LOGS - Gestor Documental
Supertiendas Cañaveral
=========================================================================

Este directorio contiene todos los archivos de registro (logs) del sistema:

📄 LOGS PRINCIPALES:

1. security.log
   - Eventos de seguridad y autenticación
   - Intentos de login (exitosos y fallidos)
   - Cambios de contraseña
   - Activación/desactivación de usuarios
   - Bloqueos de IP

2. backup.log ⭐ NUEVO
   - Operaciones de backup automático
   - Ejecuciones manuales de backups
   - Estado de backups (exitoso/fallido)
   - Tamaños y duraciones
   - Errores en backups

3. app.log ⭐ NUEVO
   - Eventos generales de la aplicación
   - Inicio/detención del servidor
   - Carga de módulos y blueprints
   - Inicializaciones de base de datos

4. errors.log ⭐ NUEVO
   - Solo errores y excepciones
   - Stack traces completos
   - Errores de base de datos
   - Fallos en operaciones críticas

📦 LOGS DE MÓDULOS:

5. facturas_digitales.log ⭐ NUEVO
   - Eventos del módulo de Facturas Digitales
   - Carga de facturas nuevas
   - Validaciones de documentos
   - Configuración de catálogos

6. relaciones.log ⭐ NUEVO
   - Eventos del módulo de Relaciones
   - Generación de relaciones
   - Recepciones digitales
   - Validaciones de facturas

=========================================================================
FORMATO DE LOGS:

[FECHA HORA] | NIVEL | MENSAJE

Niveles disponibles:
- DEBUG: Información detallada para depuración
- INFO: Eventos normales del sistema
- WARNING: Advertencias (no críticas)
- ERROR: Errores que no detienen el sistema
- CRITICAL: Errores críticos

=========================================================================
ROTACIÓN Y LIMPIEZA:

Los archivos de log se conservan indefinidamente. Para limpiar logs antiguos:

PowerShell:
  Get-ChildItem *.log | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-30)} | Remove-Item

Manual:
  Eliminar archivos .log más antiguos de 30 días

=========================================================================
MONITOREO:

Panel Web:
  http://localhost:8099/admin/monitoreo/dashboard
  Sección "Logs del Sistema"

Línea de comandos:
  # Ver últimas líneas
  Get-Content security.log -Tail 50
  Get-Content backup.log -Tail 50
  Get-Content errors.log -Tail 50

  # Buscar texto específico
  Select-String -Path *.log -Pattern "ERROR"
  Select-String -Path security.log -Pattern "LOGIN"

========================================================================= 
