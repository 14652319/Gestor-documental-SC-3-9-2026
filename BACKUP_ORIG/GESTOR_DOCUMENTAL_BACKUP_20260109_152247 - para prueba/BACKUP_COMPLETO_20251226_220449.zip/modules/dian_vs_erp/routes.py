# -*- coding: utf-8 -*-
"""
Rutas del módulo DIAN vs ERP - Sistema Híbrido v5
Integración completa del proyecto original al Gestor Documental
"""

from flask import Blueprint, render_template, request, jsonify, send_file, session, redirect, current_app
from flask_mail import Message
from werkzeug.utils import secure_filename
import os
import time
import hashlib
import io
from datetime import date, datetime
from pathlib import Path
import polars as pl
import pandas as pd

# Importaciones del sistema principal temporalmente removidas para debugging
# from decoradores_permisos import requiere_permiso, requiere_permiso_html, requiere_rol

# Importar modelos PostgreSQL y db
from extensions import db
from .models import (
    MaestroDianVsErp,
    EnvioProgramadoDianVsErp,
    UsuarioCausacionDianVsErp,
    HistorialEnvioDianVsErp,
    LogSistemaDianVsErp
)

# Importar helper de logging
from .logger_helper import (
    registrar_log,
    obtener_logs_recientes as helper_obtener_logs,
    obtener_estadisticas_logs
)

# Crear blueprint
dian_vs_erp_bp = Blueprint('dian_vs_erp', __name__)

# Configuración de rutas
BASE_DIR = Path(__file__).parent.parent.parent
UPLOADS = {
    "dian": BASE_DIR / "uploads" / "dian",
    "erp_fn": BASE_DIR / "uploads" / "erp_fn", 
    "erp_cm": BASE_DIR / "uploads" / "erp_cm",
    "acuses": BASE_DIR / "uploads" / "acuses",
    "errores": BASE_DIR / "uploads" / "rg_erp_er",
}

# Crear directorios
for path in UPLOADS.values():
    path.mkdir(parents=True, exist_ok=True)

ALLOWED_EXCEL = {".xlsx", ".xlsm", ".xls", ".csv"}

# Diccionarios de mapeo (del sistema original)
SIGLAS = {
    "factura electrónica": "FE", "factura electronica": "FE",
    "factura electrónica de exportación": "FEE",
    "nota de débito electrónica": "NDE",
    "factura electrónica de contingencia": "FEC",
    "documento soporte con no obligados": "DSNO",
    "factura electrónica de contingencia dian": "FECD",
    "documento equivalente pos": "DEPOS",
    "nota de ajuste crédito del documento equivalente": "NCDE",
    "nota de crédito electrónica": "NCE",
}

MODULO_MAP = {
    "legalización factura anticipos": "FINANCIERO",
    "factura de servicio compra": "FINANCIERO",
    "nota débito de servicios - compra": "FINANCIERO",
    "factura de servicio de reg.fijo compra": "FINANCIERO",
    "factura de servicio desde sol. anticipo": "FINANCIERO",
    "legalización factura caja menor": "FINANCIERO",
    "factura de proveedor": "COMERCIAL",
    "notas débito de proveedor": "COMERCIAL",
    "factura de consignación": "COMERCIAL",
}

# ==============================
# FUNCIONES UTILITARIAS
# ==============================

def validar_sesion():
    """Validar que el usuario tenga sesión activa"""
    if 'usuario_id' not in session or 'usuario' not in session:
        return False, {"error": "Sesión no válida", "redirect": "/login"}, 401
    return True, None, None

def save_excel_to_csv(storage, folder: Path) -> str:
    """Convertir Excel/CSV a CSV normalizado"""
    folder.mkdir(parents=True, exist_ok=True)
    fname = secure_filename(storage.filename)
    ext = os.path.splitext(fname)[1].lower()
    raw = storage.read()

    # Hash para evitar colisiones
    h = hashlib.md5(raw).hexdigest()[:10]
    base = os.path.splitext(fname)[0]
    csv_name = f"{base}_{h}.csv"
    target = folder / csv_name

    if ext in (".xlsx", ".xlsm", ".xls"):
        buf = io.BytesIO(raw)
        try:
            df = pd.read_excel(buf, dtype=str)
        except Exception:
            df = pd.read_excel(buf, engine="openpyxl", dtype=str)
        df.to_csv(target, index=False, encoding="utf-8")
    elif ext == ".csv":
        try:
            txt = raw.decode("utf-8")
        except UnicodeDecodeError:
            txt = raw.decode("latin-1")
        with open(target, "w", encoding="utf-8", newline="") as w:
            w.write(txt)
    else:
        raise ValueError(f"Extensión no soportada: {ext}")

    return str(target)

def latest_csv(path: Path) -> str:
    """Obtener el CSV más reciente de una carpeta"""
    if not path.is_dir():
        return None
    csvs = list(path.glob("*.csv"))
    if not csvs:
        return None
    csvs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return str(csvs[0])

def read_csv(path: str) -> pl.DataFrame:
    """Leer CSV con Polars"""
    if not path or not os.path.exists(path):
        return pl.DataFrame()
    
    def norm_cols(df: pl.DataFrame) -> pl.DataFrame:
        return df.rename({c: c.strip().lower() for c in df.columns})
    
    return norm_cols(pl.read_csv(path, infer_schema_length=0, ignore_errors=True, null_values=["", " "]))

# ==============================
# RUTAS DE AUTENTICACIÓN
# ==============================

@dian_vs_erp_bp.route('/api/auth/logout', methods=['POST'])
def logout():
    """
    Cerrar sesión del usuario (destruir sesión en servidor)
    Llamado por timeout automático (25 min) o por botón manual
    """
    try:
        # Limpiar sesión
        session.clear()
        
        # Log de auditoría
        current_app.logger.info('✅ Sesión cerrada correctamente en DIAN vs ERP')
        
        return jsonify({
            'success': True,
            'message': 'Sesión cerrada correctamente'
        }), 200
        
    except Exception as e:
        current_app.logger.error(f'❌ Error al cerrar sesión: {e}')
        # Aún si hay error, intentar limpiar sesión
        session.clear()
        return jsonify({
            'success': False,
            'message': 'Error al cerrar sesión pero se limpiará de todas formas'
        }), 500

# ==============================
# RUTAS PRINCIPALES
# ==============================

@dian_vs_erp_bp.route('/')
def dashboard():
    """Dashboard principal del módulo DIAN vs ERP - Template original del standalone puerto 8097"""
    # Validar sesión - TEMPORAL: Sin decorador de permisos para debugging
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    usuario = session.get('usuario', 'Usuario')
    
    # Obtener estadísticas desde PostgreSQL
    try:
        total_maestro = MaestroDianVsErp.query.count()
        total_envios = EnvioProgramadoDianVsErp.query.count()
        total_usuarios = UsuarioCausacionDianVsErp.query.count()
        stats = {
            "total_maestro": total_maestro,
            "total_envios_programados": total_envios,
            "total_usuarios_causacion": total_usuarios
        }
    except Exception as e:
        stats = {"total_maestro": 0, "total_envios_programados": 0, "total_usuarios_causacion": 0}
        print(f"Error obteniendo estadísticas: {e}")
    
    # Usar visor_dian_v2.html - Template original del standalone con funcionalidad completa
    return render_template('dian_vs_erp/visor_dian_v2.html', usuario=usuario, estadisticas=stats)

@dian_vs_erp_bp.route('/cargar')
@dian_vs_erp_bp.route('/cargar_archivos')
def cargar_archivos():
    """Página de carga de archivos"""
    # Validar sesión simple
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    return render_template('dian_vs_erp/cargar_moderno.html', usuario=session.get('usuario', 'Usuario'))

@dian_vs_erp_bp.route('/visor')
def visor_moderno():
    """Visor moderno de datos"""
    # Validar sesión simple
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    return render_template('dian_vs_erp/visor_moderno.html', usuario=session.get('usuario', 'Usuario'))

@dian_vs_erp_bp.route('/validaciones')
def validaciones():
    """Página de validaciones DIAN vs ERP"""
    # Validar sesión simple
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    return render_template('dian_vs_erp/validaciones.html', usuario=session.get('usuario', 'Usuario'))

@dian_vs_erp_bp.route('/reportes')
def reportes():
    """Página de reportes DIAN vs ERP"""
    # Validar sesión simple
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    return render_template('dian_vs_erp/reportes.html', usuario=session.get('usuario', 'Usuario'))

@dian_vs_erp_bp.route('/configuracion')
def configuracion():
    """Página de configuración del módulo"""
    # Validar sesión simple
    if 'usuario_id' not in session or 'usuario' not in session:
        return redirect('/login')
    
    return render_template('dian_vs_erp/configuracion.html', usuario=session.get('usuario', 'Usuario'))

@dian_vs_erp_bp.route('/api/dian')
def api_dian():
    """
    API: Lee maestro consolidado desde POSTGRESQL (migrado desde SQLite)
    Compatible con el frontend original del standalone
    
    PARÁMETROS DE CONSULTA (opcionales):
    - fecha_inicial: YYYY-MM-DD (por defecto: primer día del mes actual)
    - fecha_final: YYYY-MM-DD (por defecto: hoy)
    - buscar: texto para buscar en NIT, razón social, prefijo, folio
    - page: página actual (para paginación)
    - size: registros por página (por defecto: 500)
    """
    try:
        from datetime import date
        import re
        
        # Obtener parámetros de consulta
        fecha_inicial = request.args.get('fecha_inicial', '').strip()
        fecha_final = request.args.get('fecha_final', '').strip()
        buscar = request.args.get('buscar', '').strip()
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 500))
        
        # 🔥 VALIDACIÓN Y DEFAULT: Si no hay fechas, usar TODO EL MES ACTUAL
        fecha_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        
        if not fecha_inicial or not fecha_pattern.match(fecha_inicial):
            hoy = date.today()
            fecha_inicial = f"{hoy.year}-{hoy.month:02d}-01"  # PRIMER DÍA DEL MES ACTUAL
        
        if not fecha_final or not fecha_pattern.match(fecha_final):
            hoy = date.today()
            fecha_final = hoy.strftime("%Y-%m-%d")  # HOY
        
        print(f"[API DIAN] Consultando PostgreSQL: {fecha_inicial} a {fecha_final}, buscar: '{buscar}'")
        
        # ✅ CONSULTAR DESDE POSTGRESQL
        query = MaestroDianVsErp.query
        
        # Filtro de fechas
        query = query.filter(MaestroDianVsErp.fecha_emision >= fecha_inicial)
        query = query.filter(MaestroDianVsErp.fecha_emision <= fecha_final)
        
        # Filtro de búsqueda (NIT, razón social, prefijo, folio)
        if buscar:
            query = query.filter(
                db.or_(
                    MaestroDianVsErp.nit_emisor.like(f'%{buscar}%'),
                    MaestroDianVsErp.razon_social.like(f'%{buscar}%'),
                    MaestroDianVsErp.prefijo.like(f'%{buscar}%'),
                    MaestroDianVsErp.folio.like(f'%{buscar}%')
                )
            )
        
        # Ordenar por fecha de emisión descendente
        query = query.order_by(MaestroDianVsErp.fecha_emision.desc())
        
        # Paginación
        offset = (page - 1) * size
        registros = query.limit(size).offset(offset).all()
        
        # Convertir a diccionarios
        datos = []
        for registro in registros:
            # Convertir forma_pago: 1=Contado, 2=Crédito (igual que puerto 8097)
            forma_pago_raw = registro.forma_pago or ""
            if forma_pago_raw == "1":
                forma_pago_texto = "Contado"
            elif forma_pago_raw == "2":
                forma_pago_texto = "Crédito"
            else:
                forma_pago_texto = "Crédito"  # Default
            
            # Calcular estado_contable_validado (igual que puerto 8097)
            # LÓGICA: Si tiene modulo Y modulo != "No Registrada" → "Causada", sino → "No Registrada"
            modulo_val = registro.modulo or ""
            if modulo_val and modulo_val != "No Registrada":
                estado_contable_validado = "Causada"
            else:
                estado_contable_validado = "No Registrada"
            
            # Validar estado_aprobacion (igual que puerto 8097)
            # LÓGICA: Si existe estado_aprobacion → usar ese, sino usar estado_contable (o "Pendiente")
            estado_aprobacion_val = registro.estado_aprobacion or ""
            if estado_aprobacion_val:
                estado_aprobacion_final = estado_aprobacion_val
            else:
                estado_aprobacion_final = registro.estado_contable or "Pendiente"
            
            datos.append({
                "nit_emisor": registro.nit_emisor,
                "nombre_emisor": registro.razon_social or "",
                "fecha_emision": registro.fecha_emision.strftime("%Y-%m-%d") if registro.fecha_emision else "",
                "tipo_documento": registro.tipo_documento or "",
                "prefijo": registro.prefijo or "",
                "folio": registro.folio or "",
                "valor": float(registro.valor) if registro.valor else 0,
                "cufe": registro.cufe or "",  # ✅ Ahora existe
                "estado_aprobacion": estado_aprobacion_final,  # ✅ VALIDADO: estado_aprobacion o estado_contable
                "forma_pago_texto": forma_pago_texto,  # ✅ Convertido: 1→Contado, 2→Crédito
                "estado_contable": estado_contable_validado,  # ✅ CALCULADO: Causada o No Registrada
                "dias_desde_emision": registro.dias_desde_emision or 0,  # ✅ Ahora existe
                "tipo_tercero": registro.tipo_tercero or "",  # ✅ Ahora existe
                "usuario_solicitante": "",
                "usuario_aprobador": "",
                "observaciones": "",
                "modulo": registro.modulo or "",  # ✅ Ahora existe
                "doc_causado_por": registro.doc_causado_por or "",  # ✅ Ahora existe
                "tiene_usuarios_email": False
            })
        
        print(f"✅ Retornando {len(datos):,} registros desde PostgreSQL")
        return jsonify(datos)
        
    except Exception as e:
        print(f"❌ Error en API DIAN: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Error al consultar base de datos: {str(e)}"}), 500

@dian_vs_erp_bp.route('/descargar_plantilla/<tipo>')
def descargar_plantilla(tipo):
    """Descargar plantillas Excel para diferentes tipos de archivo"""
    try:
        plantillas_dir = BASE_DIR / "plantillas"
        
        if tipo == "dian":
            archivo = plantillas_dir / "plantilla_dian.xlsx"
        elif tipo == "erp":
            archivo = plantillas_dir / "plantilla_erp.xlsx"
        elif tipo == "acuses":
            archivo = plantillas_dir / "plantilla_acuses.xlsx"
        else:
            return jsonify({"error": "Tipo de plantilla no válido"}), 400
        
        if archivo.exists():
            return send_file(str(archivo), as_attachment=True)
        else:
            # Si no existe la plantilla, crear una básica
            print(f"⚠️ Plantilla {tipo} no encontrada, creando básica...")
            
            # Crear DataFrame básico según el tipo
            if tipo == "dian":
                data = {
                    "nit_emisor": ["123456789"],
                    "nombre_emisor": ["Empresa Ejemplo"],
                    "fecha_emision": ["2024-11-30"],
                    "tipo_documento": ["Factura Electrónica"],
                    "prefijo": ["FV"],
                    "folio": ["001"],
                    "valor": [1000000],
                    "cufe": ["ejemplo_cufe_123"]
                }
            elif tipo == "erp":
                data = {
                    "nit": ["123456789"],
                    "prefijo": ["FV"],
                    "folio": ["001"],
                    "valor": [1000000],
                    "fecha": ["2024-11-30"],
                    "modulo": ["COMERCIAL"]
                }
            else:  # acuses
                data = {
                    "cufe": ["ejemplo_cufe_123"],
                    "estado": ["Aprobado"],
                    "fecha_acuse": ["2024-11-30"]
                }
            
            df = pl.DataFrame(data)
            
            # Crear directorio si no existe
            plantillas_dir.mkdir(parents=True, exist_ok=True)
            
            # Guardar como Excel
            df.write_excel(str(archivo))
            
            return send_file(str(archivo), as_attachment=True)
        
    except Exception as e:
        print(f"❌ Error descargando plantilla {tipo}: {e}")
        return jsonify({"error": f"Error al descargar plantilla: {e}"}), 500

@dian_vs_erp_bp.route('/subir_archivos', methods=['POST'])
@dian_vs_erp_bp.route('/api/subir_archivos', methods=['POST'])
def subir_archivos():
    """
    Subir y procesar archivos Excel/CSV
    Compatible con el sistema original
    """
    try:
        # Validar sesión simple para API endpoints
        if 'usuario_id' not in session or 'usuario' not in session:
            return jsonify({"error": "Sesión no válida", "redirect": "/login"}), 401
        
        archivos_procesados = []
        usuario = session.get('usuario', 'Usuario')
        
        # Procesar cada tipo de archivo
        for key, folder in UPLOADS.items():
            f = request.files.get(key)
            if not f or not f.filename:
                continue
            
            ext = os.path.splitext(f.filename)[1].lower()
            if ext not in ALLOWED_EXCEL:
                return jsonify({"mensaje": f"❌ {f.filename}: extensión no soportada"}), 400
            
            # Guardar archivo convertido a CSV
            ruta_csv = save_excel_to_csv(f, folder)
            
            archivos_procesados.append({
                "tipo": key,
                "nombre": f.filename,
                "ruta_csv": ruta_csv,
                "tamaño": len(f.read())
            })
        
        if len(archivos_procesados) == 0:
            return jsonify({"mensaje": "⚠️ No se recibió ningún archivo."}), 400
        
        # Procesar y actualizar maestro
        msg = actualizar_maestro()
        
        mensaje_resultado = f"✅ {len(archivos_procesados)} archivo(s) procesado(s) exitosamente\n\n{msg}"
        
        return jsonify({
            "mensaje": mensaje_resultado,
            "archivos": archivos_procesados
        })
        
    except Exception as e:
        print(f"❌ Error en subida: {e}")
        return jsonify({"mensaje": f"❌ Error: {e}"}), 500

@dian_vs_erp_bp.route('/api/forzar_procesar')
def forzar_procesar():
    """Forzar reprocesamiento del maestro"""
    try:
        # Validar sesión simple para API endpoints
        if 'usuario_id' not in session or 'usuario' not in session:
            return jsonify({"error": "Sesión no válida", "redirect": "/login"}), 401
        
        msg = actualizar_maestro()
        return jsonify({"mensaje": msg})
    except Exception as e:
        return jsonify({"mensaje": f"❌ Error: {e}"}), 500

# ==============================
# PROCESAMIENTO PRINCIPAL 
# ==============================

def actualizar_maestro() -> str:
    """
    Sistema híbrido: Procesamiento principal con PostgreSQL
    Migrado desde SQLite para usar base de datos principal
    """
    import re
    
    t0 = time.time()
    
    db_path = BASE_DIR / "maestro" / "maestro.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Funciones Python UDF (mantenidas para compatibilidad futura)
    def extraer_prefijo(docto: str) -> str:
        if not docto:
            return ""
        return re.sub(r'[0-9\-\.]', '', str(docto)).strip()
    
    def extraer_folio(docto: str) -> str:
        if not docto:
            return ""
        return re.sub(r'[^0-9]', '', str(docto))
    
    def ultimos_8_sin_ceros(folio: str) -> str:
        if not folio:
            return "0"
        numeros = re.sub(r'[^0-9]', '', str(folio))
        if not numeros:
            return "0"
        ultimos = numeros[-8:] if len(numeros) >= 8 else numeros
        return ultimos.lstrip('0') or '0'
    
    def mapear_modulo(clase: str) -> str:
        if not clase:
            return ""
        return MODULO_MAP.get(str(clase).lower().strip(), "")
    
    # TODO: Implementar procesamiento completo con PostgreSQL
    # Por ahora, procesamiento simplificado para archivos CSV
    
    # Cargar archivos CSV
    f_dian = latest_csv(UPLOADS["dian"])
    if not f_dian:
        return "⚠️ No hay archivos DIAN. Sube un Excel/CSV de DIAN para procesar."
    
    # Cargar DIAN
    d = read_csv(f_dian)
    registros_dian = d.height if d.height > 0 else 0
    
    # Cargar ERP (FN + CM)
    erp_frames = []
    for key in ["erp_fn", "erp_cm", "errores"]:
        csv_path = latest_csv(UPLOADS[key])
        if csv_path:
            erp_df = read_csv(csv_path)
            if erp_df.height > 0:
                erp_frames.append(erp_df)
    
    registros_erp = 0
    if erp_frames:
        erp = pl.concat(erp_frames, how="diagonal")
        registros_erp = erp.height
    
    # Guardar en PostgreSQL si hay registros
    total = 0
    if registros_dian > 0:
        try:
            # Procesar y guardar en PostgreSQL
            d_pd = d.to_pandas()
            
            # Limpiar registros anteriores (opcional)
            # MaestroDianVsErp.query.delete()
            
            # Insertar nuevos registros
            for idx, row in d_pd.iterrows():
                nuevo = MaestroDianVsErp(
                    nit_emisor=str(row.get('nit emisor', row.get('nit_emisor', ''))),
                    razon_social=str(row.get('nombre emisor', row.get('razon social', ''))),
                    fecha_emision=str(row.get('fecha emision', row.get('fecha_emision', date.today()))),
                    tipo_documento=str(row.get('tipo documento', row.get('tipo_documento', 'Factura Electrónica'))),
                    prefijo=extraer_prefijo(str(row.get('prefijo', ''))),
                    folio=extraer_folio(str(row.get('folio', row.get('numero', '')))),
                    valor=float(row.get('valor', 0)),
                    estado_aprobacion=str(row.get('estado aprobacion', row.get('estado_aprobacion', 'Pendiente'))),
                    forma_pago=str(row.get('forma pago', row.get('forma_pago', 'Crédito')))
                )
                db.session.add(nuevo)
                total += 1
                
                # Commit cada 100 registros
                if total % 100 == 0:
                    db.session.commit()
            
            # Commit final
            db.session.commit()
            print(f"✅ {total} registros guardados en PostgreSQL")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Error guardando en PostgreSQL: {e}")
            total = 0
    
    tiempo = time.time() - t0
    
    msg = f"""✅ Sistema DIAN vs ERP actualizado en {tiempo:0.1f}s
📊 DIAN CSV: {registros_dian:,} registros
📊 ERP CSV: {registros_erp:,} registros  
🎯 Guardados en PostgreSQL: {total:,} registros
🚀 Base de datos: PostgreSQL (gestor_documental)"""
    
    return msg

# ============================================
# ENDPOINTS DE API FALTANTES PARA EL FRONTEND
# ============================================

@dian_vs_erp_bp.route('/api/actualizar_nit', methods=['POST'])
def api_actualizar_nit():
    """
    Actualiza un campo para todos los documentos de un NIT
    """
    try:
        data = request.get_json()
        nit = data.get('nit')
        campo = data.get('campo')
        valor = data.get('valor')
        
        if not all([nit, campo]):
            return jsonify({'exito': False, 'mensaje': 'Faltan parámetros requeridos'}), 400
        
        # Simular actualización exitosa
        # En una implementación real, aquí actualizarías la base de datos
        print(f"🔄 Simulando actualización: NIT {nit}, campo '{campo}' = '{valor}'")
        
        return jsonify({
            'exito': True,
            'mensaje': f'Campo {campo} actualizado para todas las facturas del NIT {nit}'
        })
        
    except Exception as e:
        print(f"❌ Error actualizando NIT: {e}")
        return jsonify({'exito': False, 'mensaje': f'Error interno: {e}'}), 500

@dian_vs_erp_bp.route('/api/actualizar_campo', methods=['POST'])
def api_actualizar_campo():
    """
    Actualiza un campo individual por CUFE
    """
    try:
        data = request.get_json()
        cufe = data.get('cufe')
        campo = data.get('campo')
        valor = data.get('valor')
        
        if not all([cufe, campo]):
            return jsonify({'exito': False, 'mensaje': 'Faltan parámetros requeridos'}), 400
        
        # Simular actualización exitosa
        print(f"🔄 Simulando actualización individual: CUFE {cufe}, campo '{campo}' = '{valor}'")
        
        return jsonify({
            'exito': True,
            'mensaje': f'Campo {campo} actualizado correctamente'
        })
        
    except Exception as e:
        print(f"❌ Error actualizando campo: {e}")
        return jsonify({'exito': False, 'mensaje': f'Error interno: {e}'}), 500

@dian_vs_erp_bp.route('/api/enviar_emails', methods=['POST'])
def api_enviar_emails():
    """
    Envía emails individuales para facturas
    """
    try:
        data = request.get_json()
        cufe = data.get('cufe')
        destinatarios = data.get('destinatarios', [])
        
        if not cufe or not destinatarios:
            return jsonify({'exito': False, 'mensaje': 'Faltan parámetros requeridos'}), 400
        
        # Simular envío exitoso
        enviados = len(destinatarios)
        print(f"📧 Simulando envío de {enviados} emails para CUFE {cufe}")
        
        return jsonify({
            'exito': True,
            'enviados': enviados,
            'fallidos': 0
        })
        
    except Exception as e:
        print(f"❌ Error enviando emails: {e}")
        return jsonify({'exito': False, 'mensaje': f'Error interno: {e}'}), 500


@dian_vs_erp_bp.route('/api/enviar_email_agrupado', methods=['POST'])
def api_enviar_email_agrupado():
    """
    Enviar TODAS las facturas agrupadas en UN SOLO EMAIL a cada destinatario
    """
    try:
        print("=" * 80)
        print("📧 ENDPOINT ENVIAR EMAIL AGRUPADO - INICIO")
        print("=" * 80)
        
        data = request.get_json()
        print(f"📦 Datos recibidos: {data}")
        
        destinatarios = data.get('destinatarios', [])
        cufes = data.get('cufes', [])
        
        print(f"👥 Destinatarios: {len(destinatarios)}")
        print(f"📄 CUFEs: {len(cufes)}")
        
        if not destinatarios:
            print("❌ Error: No hay destinatarios")
            return jsonify({'exito': False, 'mensaje': 'No hay destinatarios'}), 400
        
        if not cufes:
            print("❌ Error: No hay facturas para enviar")
            return jsonify({'exito': False, 'mensaje': 'No hay facturas para enviar'}), 400
        
        # Obtener todas las facturas desde PostgreSQL
        try:
            print(f"📧 Consultando {len(cufes)} facturas desde PostgreSQL...")
            
            # Consultar facturas por CUFEs usando sintaxis correcta de SQLAlchemy
            facturas_query = db.session.query(MaestroDianVsErp).filter(
                MaestroDianVsErp.cufe.in_(cufes)
            ).all()
            
            print(f"✅ Encontradas {len(facturas_query)} facturas en BD")
            
            if not facturas_query:
                return jsonify({'exito': False, 'mensaje': 'No se encontraron facturas'}), 404
            
            # Convertir a diccionarios (formato compatible con puerto 8097)
            facturas = []
            for f in facturas_query:
                facturas.append({
                    'cufe': f.cufe or '',
                    'nit_emisor': f.nit_emisor or '',
                    'nombre_emisor': f.razon_social or '',
                    'razon_social': f.razon_social or '',
                    'fecha_emision': f.fecha_emision.strftime('%Y-%m-%d') if f.fecha_emision else '',
                    'tipo_documento': f.tipo_documento or 'Factura Electrónica',
                    'prefijo': f.prefijo or '',
                    'folio': f.folio or '',
                    'valor': float(f.valor) if f.valor else 0,
                    'estado_aprobacion': f.estado_aprobacion or 'Pendiente',
                    'forma_pago_texto': f.forma_pago or 'Crédito',
                    'estado_contable': f.estado_contable or 'No Registrada',
                    'causada': f.causada or False,
                    'recibida': f.recibida or False
                })
        
        except Exception as e:
            print(f"❌ Error obteniendo facturas desde PostgreSQL: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({'exito': False, 'mensaje': f'Error consultando facturas: {str(e)}'}), 500
        
        # Enviar UN email agrupado por destinatario
        enviados = 0
        fallidos = 0
        errores = []
        
        print(f"📧 Enviando {len(facturas)} facturas agrupadas a {len(destinatarios)} destinatarios")
        
        for dest in destinatarios:
            correo = dest.get('correo')
            nombre = dest.get('nombre', correo)
            
            try:
                # Calcular días desde emisión
                from datetime import datetime, date
                fecha_hoy = date.today()
                
                # Generar HTML del email con tabla de facturas mejorada
                html_facturas = """
                <table style="width:100%; border-collapse:collapse; margin:20px 0; font-size:13px;">
                    <thead>
                        <tr style="background-color:#166534; color:white;">
                            <th style="padding:8px; border:1px solid #ddd;">NIT</th>
                            <th style="padding:8px; border:1px solid #ddd;">Razón Social</th>
                            <th style="padding:8px; border:1px solid #ddd;">Prefijo-Folio</th>
                            <th style="padding:8px; border:1px solid #ddd;">Fecha Emisión</th>
                            <th style="padding:8px; border:1px solid #ddd;">Días</th>
                            <th style="padding:8px; border:1px solid #ddd;">Valor</th>
                            <th style="padding:8px; border:1px solid #ddd;">Estado</th>
                            <th style="padding:8px; border:1px solid #ddd;">Documento</th>
                        </tr>
                    </thead>
                    <tbody>
                """
                
                total_valor = 0
                for factura in facturas:
                    valor = factura.get('valor', 0)
                    total_valor += valor
                    
                    # Calcular días desde emisión
                    dias = ''
                    fecha_emision_str = factura.get('fecha_emision', '')
                    if fecha_emision_str:
                        try:
                            fecha_emision = datetime.strptime(fecha_emision_str, '%Y-%m-%d').date()
                            dias_transcurridos = (fecha_hoy - fecha_emision).days
                            dias = str(dias_transcurridos)
                        except:
                            dias = '-'
                    
                    # Link al documento DIAN
                    cufe = factura.get('cufe', '')
                    link_dian = ''
                    if cufe:
                        link_dian = f'<a href="https://catalogo-vpfe.dian.gov.co/User/SearchDocument?DocumentKey={cufe}" target="_blank" style="color:#166534; text-decoration:none;">📄 Ver</a>'
                    else:
                        link_dian = '<span style="color:#999;">-</span>'
                    
                    html_facturas += f"""
                        <tr>
                            <td style="padding:6px; border:1px solid #ddd;">{factura.get('nit_emisor', '')}</td>
                            <td style="padding:6px; border:1px solid #ddd;">{factura.get('razon_social', '')}</td>
                            <td style="padding:6px; border:1px solid #ddd;">{factura.get('prefijo', '')}-{factura.get('folio', '')}</td>
                            <td style="padding:6px; border:1px solid #ddd; text-align:center;">{fecha_emision_str}</td>
                            <td style="padding:6px; border:1px solid #ddd; text-align:center;">{dias}</td>
                            <td style="padding:6px; border:1px solid #ddd; text-align:right;">${valor:,.2f}</td>
                            <td style="padding:6px; border:1px solid #ddd;">{factura.get('estado_aprobacion', 'Pendiente')}</td>
                            <td style="padding:6px; border:1px solid #ddd; text-align:center;">{link_dian}</td>
                        </tr>
                    """
                
                html_facturas += f"""
                    </tbody>
                    <tfoot>
                        <tr style="background-color:#f9fafb; font-weight:bold;">
                            <td colspan="5" style="padding:10px; border:1px solid #ddd; text-align:right;">TOTAL</td>
                            <td style="padding:10px; border:1px solid #ddd; text-align:right;">${total_valor:,.2f}</td>
                            <td colspan="2" style="padding:10px; border:1px solid #ddd;">{len(facturas)} facturas</td>
                        </tr>
                    </tfoot>
                </table>
                """
                
                html_body = f"""
                <html>
                <body style="font-family: Arial, sans-serif; color: #333;">
                    <div style="max-width: 1000px; margin: 0 auto; padding: 20px;">
                        <h2 style="color: #166534;">📧 Facturas Electrónicas - Resumen Agrupado</h2>
                        <p>Estimado/a <strong>{nombre}</strong>,</p>
                        <p>Le enviamos el siguiente resumen de <strong>{len(facturas)} facturas electrónicas</strong>:</p>
                        
                        {html_facturas}
                        
                        <div style="margin-top: 20px; padding: 15px; background-color: #f0fdf4; border-left: 4px solid #166534; border-radius: 4px;">
                            <p style="margin: 0; color: #166534; font-weight: bold;">💡 Información del listado:</p>
                            <ul style="margin: 10px 0; color: #666;">
                                <li><strong>Días:</strong> Días transcurridos desde la fecha de emisión</li>
                                <li><strong>Estado:</strong> Estado de aprobación en el sistema</li>
                                <li><strong>Documento:</strong> Click en "📄 Ver" para consultar el documento en la DIAN</li>
                            </ul>
                        </div>
                        
                        <p style="margin-top: 30px; color: #666; font-size: 14px;">
                            Este es un correo automático generado por el Sistema de Gestión Documental - DIAN vs ERP.
                        </p>
                    </div>
                </body>
                </html>
                """
                
                # Enviar email con Flask-Mail
                from flask_mail import Message
                msg = Message(
                    subject=f"Facturas Electrónicas - Resumen Agrupado ({len(facturas)} facturas)",
                    recipients=[correo],
                    html=html_body
                )
                
                from flask import current_app
                current_app.extensions['mail'].send(msg)
                
                enviados += 1
                print(f"✅ Email agrupado REAL enviado a {correo} ({len(facturas)} facturas)")
            
            except Exception as e:
                fallidos += 1
                error_msg = str(e)
                errores.append(f"{nombre}: {error_msg}")
                print(f"❌ Error enviando email a {correo}: {error_msg}")
                import traceback
                traceback.print_exc()
        
        mensaje_resultado = f"Enviados: {enviados}/{len(destinatarios)} - Total facturas: {len(facturas)}"
        
        return jsonify({
            'exito': enviados > 0,
            'mensaje': mensaje_resultado,
            'enviados': enviados,
            'fallidos': fallidos,
            'total_facturas': len(facturas),
            'errores': errores
        })
        
    except Exception as e:
        print(f"❌ Error en envío agrupado: {e}")
        return jsonify({'exito': False, 'mensaje': str(e)}), 500


# ====================================
# CONFIGURACIÓN DEL SISTEMA
# ====================================

@dian_vs_erp_bp.route('/config')
def config_dian_erp():
    """Página de configuración del sistema DIAN vs ERP"""
    return render_template('dian_vs_erp/configuracion.html')


@dian_vs_erp_bp.route('/api/dian_usuarios/por_nit/<nit>', methods=['GET'])
def obtener_usuarios_dian_por_nit(nit):
    """Obtiene usuarios configurados para un NIT específico"""
    try:
        # ✅ CONSULTAR BASE DE DATOS REAL
        usuarios_db = UsuarioAsignadoDianVsErp.query.filter_by(nit=nit).all()
        
        usuarios = []
        for usuario in usuarios_db:
            # Separar nombre completo en nombres y apellidos (aproximación)
            partes_nombre = usuario.nombre.split(' ', 1) if usuario.nombre else ['', '']
            usuarios.append({
                'nombres': partes_nombre[0] if len(partes_nombre) > 0 else '',
                'apellidos': partes_nombre[1] if len(partes_nombre) > 1 else '',
                'correo': usuario.correo,
                'tipo': 'APROBADOR',  # Por defecto, podría agregarse un campo en el modelo
                'activo': usuario.activo
            })
        
        return jsonify({
            'status': 'success',
            'nit': nit,
            'usuarios': usuarios,
            'total': len(usuarios)
        })
        
    except Exception as e:
        log_security(f"ERROR OBTENER USUARIOS NIT {nit} | {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Error obteniendo usuarios: {str(e)}'
        }), 500
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error obteniendo usuarios: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/terceros/buscar_por_nit/<nit>', methods=['GET'])
def buscar_tercero_por_nit(nit):
    """
    Busca un tercero en PostgreSQL por NIT y retorna su razón social
    Usado para autocompletar el campo de razón social en el modal de agregar usuario
    """
    try:
        import psycopg2
        from psycopg2.extras import RealDictCursor
        
        # Obtener configuración de la BD desde .env
        db_config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': os.getenv('DB_PORT', '5432'),
            'database': os.getenv('DB_NAME', 'gestor_documental'),
            'user': os.getenv('DB_USER', 'gestor_user'),
            'password': os.getenv('DB_PASSWORD', 'password')
        }
        
        conn = psycopg2.connect(**db_config, cursor_factory=RealDictCursor)
        cursor = conn.cursor()
        
        # Buscar tercero por NIT
        query = """
            SELECT 
                tercero_id,
                nit,
                razon_social,
                tipo_persona,
                activo
            FROM terceros
            WHERE nit = %s
            LIMIT 1
        """
        
        cursor.execute(query, (nit,))
        tercero = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if tercero:
            print(f"✅ Tercero encontrado: NIT {nit} - {tercero['razon_social']}")
            return jsonify({
                'exito': True,
                'tercero': dict(tercero)
            })
        else:
            print(f"⚠️ No se encontró tercero con NIT: {nit}")
            return jsonify({
                'exito': False,
                'mensaje': f'No se encontró un tercero con NIT {nit}'
            }), 404
            
    except Exception as e:
        print(f"❌ Error buscando tercero NIT {nit}: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'exito': False,
            'mensaje': f'Error al buscar tercero: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/dian_usuarios/agregar', methods=['POST'])
def agregar_usuario_dian():
    """Agrega un nuevo usuario para el envío de emails"""
    try:
        data = request.get_json()
        
        # Validar campos requeridos
        campos_requeridos = ['nit', 'nombres', 'apellidos', 'correo', 'tipo']
        for campo in campos_requeridos:
            if not data.get(campo):
                return jsonify({
                    'status': 'error',
                    'message': f'El campo {campo} es requerido'
                }), 400
        
        # ✅ GUARDAR EN BASE DE DATOS REAL
        nombre_completo = f"{data['nombres']} {data['apellidos']}"
        nuevo_usuario = UsuarioAsignadoDianVsErp(
            nit=data['nit'],
            correo=data['correo'],
            nombre=nombre_completo,
            activo=True
        )
        
        db.session.add(nuevo_usuario)
        db.session.commit()
        
        log_security(f"USUARIO DIAN AGREGADO | nit={data['nit']} | correo={data['correo']} | nombre={nombre_completo}")
        
        return jsonify({
            'status': 'success',
            'message': 'Usuario agregado correctamente',
            'usuario': {
                'nit': data['nit'],
                'nombres': data['nombres'],
                'apellidos': data['apellidos'],
                'correo': data['correo'],
                'tipo': data['tipo'],
                'activo': True
            }
        })
        
    except Exception as e:
        db.session.rollback()
        log_security(f"ERROR AGREGAR USUARIO DIAN | {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Error agregando usuario: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/dian_usuarios/actualizar', methods=['PUT'])
def actualizar_usuario_dian():
    """Actualiza la información de un usuario"""
    try:
        data = request.get_json()
        
        # Validar campos requeridos
        if not data.get('correo'):
            return jsonify({
                'status': 'error',
                'message': 'El correo es requerido para identificar el usuario'
            }), 400
        
        # Simular actualización en base de datos
        # En una implementación real, aquí se actualizaría en la BD
        
        return jsonify({
            'status': 'success',
            'message': 'Usuario actualizado correctamente'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error actualizando usuario: {str(e)}'
        }), 500


# ================================
# ENDPOINTS DE CONFIGURACIÓN SMTP
# ================================

@dian_vs_erp_bp.route('/api/config/smtp', methods=['GET'])
def obtener_config_smtp():
    """Obtiene la configuración SMTP global del sistema (sin contraseña por seguridad)"""
    try:
        # ✅ USAR CONFIGURACIÓN GLOBAL DEL SISTEMA
        config = {
            'smtp_host': current_app.config.get('MAIL_SERVER', 'No configurado'),
            'smtp_port': str(current_app.config.get('MAIL_PORT', 'No configurado')),
            'smtp_user': current_app.config.get('MAIL_USERNAME', 'No configurado'),
            'smtp_pass': '***********' if current_app.config.get('MAIL_PASSWORD') else 'No configurado',
            'from_name': 'Sistema Facturas DIAN - Supertiendas Cañaveral',
            'from_email': current_app.config.get('MAIL_DEFAULT_SENDER', current_app.config.get('MAIL_USERNAME', 'No configurado')),
            'use_ssl': current_app.config.get('MAIL_USE_SSL', False),
            'use_tls': current_app.config.get('MAIL_USE_TLS', False),
            'reply_to': current_app.config.get('MAIL_REPLY_TO', ''),
            'configurado': bool(current_app.config.get('MAIL_USERNAME') and current_app.config.get('MAIL_PASSWORD')),
            'mensaje_info': '⚙️ Esta configuración es global del sistema Gestor Documental'
        }
        
        return jsonify({
            'exito': True,
            'config': config
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo configuración: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/config/smtp', methods=['POST'])
def guardar_config_smtp():
    """La configuración SMTP es global del sistema - No se permite modificar desde este módulo"""
    return jsonify({
        'exito': False,
        'mensaje': '⚠️ La configuración SMTP es global del sistema. Para modificarla, edite el archivo .env y reinicie el servidor.'
    }), 403


@dian_vs_erp_bp.route('/api/config/smtp/probar', methods=['GET'])
def probar_conexion_smtp():
    """Prueba la conexión SMTP usando la configuración global"""
    try:
        # Verificar si hay configuración
        if not current_app.config.get('MAIL_USERNAME') or not current_app.config.get('MAIL_PASSWORD'):
            return jsonify({
                'exito': False,
                'mensaje': '⚠️ No hay configuración SMTP. Configure las variables MAIL_* en el archivo .env'
            }), 400
        
        # Intentar envío de correo de prueba a un destinatario interno
        from extensions import mail
        
        msg = Message(
            subject='🧪 Prueba de Conexión SMTP - DIAN vs ERP',
            recipients=[current_app.config.get('MAIL_USERNAME')],  # Enviar a la misma cuenta
            html='''
            <html>
            <body style="font-family: Arial, sans-serif;">
                <h2 style="color: #166534;">✅ Prueba de Conexión SMTP Exitosa</h2>
                <p>Este es un correo de prueba desde el módulo <strong>DIAN vs ERP</strong>.</p>
                <p>La configuración SMTP está funcionando correctamente.</p>
                <hr>
                <p style="color: #666; font-size: 12px;">
                    Enviado desde: <strong>{}</strong><br>
                    Servidor: <strong>{}</strong><br>
                    Puerto: <strong>{}</strong>
                </p>
            </body>
            </html>
            '''.format(
                current_app.config.get('MAIL_DEFAULT_SENDER', 'No configurado'),
                current_app.config.get('MAIL_SERVER', 'No configurado'),
                current_app.config.get('MAIL_PORT', 'No configurado')
            )
        )
        
        # Configurar Reply-To si está definido
        if current_app.config.get('MAIL_REPLY_TO'):
            msg.reply_to = current_app.config.get('MAIL_REPLY_TO')
        
        mail.send(msg)
        
        return jsonify({
            'exito': True,
            'mensaje': f'✅ Conexión SMTP exitosa. Email de prueba enviado a {current_app.config.get("MAIL_USERNAME")}'
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'❌ Error en conexión SMTP: {str(e)}'
        }), 500


# ========================================
# ENDPOINTS DE ENVÍOS PROGRAMADOS
# ========================================

@dian_vs_erp_bp.route('/api/config/envios', methods=['GET'])
def obtener_envios_programados():
    """Obtiene todas las configuraciones de envíos programados desde PostgreSQL"""
    try:
        # Consultar desde PostgreSQL
        envios_query = EnvioProgramadoDianVsErp.query.order_by(
            EnvioProgramadoDianVsErp.activo.desc(),
            EnvioProgramadoDianVsErp.hora_envio.asc()
        ).all()
        
        envios = [envio.to_dict() for envio in envios_query]
        
        return jsonify({
            'exito': True,
            'envios': envios
        })
        
    except Exception as e:
        current_app.logger.error(f"Error obteniendo envíos programados: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/config/envios', methods=['POST'])
def crear_envio_programado():
    """Crea una nueva configuración de envío programado en PostgreSQL"""
    try:
        data = request.json
        
        # Crear nuevo registro en PostgreSQL
        nuevo_envio = EnvioProgramadoDianVsErp(
            nombre=data['nombre'],
            tipo=data['tipo'],
            dias_minimos=data.get('dias_minimos'),
            requiere_acuses_minimo=data.get('requiere_acuses_minimo', 2),
            estados_incluidos=json.dumps(data.get('estados_incluidos', [])) if data.get('estados_incluidos') else None,
            estados_excluidos=json.dumps(data.get('estados_excluidos', [])) if data.get('estados_excluidos') else None,
            hora_envio=data['hora_envio'],
            frecuencia=data['frecuencia'],
            dias_semana=data.get('dias_semana'),
            tipo_destinatario=data['tipo_destinatario'],
            email_cc=data.get('email_cc'),
            activo=data.get('activo', True)
        )
        
        db.session.add(nuevo_envio)
        db.session.commit()
        config_id = nuevo_envio.id
        
        # Recargar scheduler
        try:
            from scheduler_envios_programados import scheduler_global
            if scheduler_global:
                scheduler_global.detener_scheduler()
                scheduler_global.iniciar_scheduler()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'mensaje': 'Configuración creada exitosamente',
            'id': config_id
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creando envío programado: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/config/envios/<int:id>', methods=['PUT'])
def actualizar_envio_programado(id):
    """Actualiza una configuración existente en PostgreSQL"""
    try:
        data = request.json
        
        # Buscar registro en PostgreSQL
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        # Actualizar campos
        envio.nombre = data['nombre']
        envio.tipo = data['tipo']
        envio.dias_minimos = data.get('dias_minimos')
        envio.requiere_acuses_minimo = data.get('requiere_acuses_minimo', 2)
        envio.estados_incluidos = json.dumps(data.get('estados_incluidos', [])) if data.get('estados_incluidos') else None
        envio.estados_excluidos = json.dumps(data.get('estados_excluidos', [])) if data.get('estados_excluidos') else None
        envio.hora_envio = data['hora_envio']
        envio.frecuencia = data['frecuencia']
        envio.dias_semana = data.get('dias_semana')
        envio.tipo_destinatario = data['tipo_destinatario']
        envio.email_cc = data.get('email_cc')
        envio.activo = data.get('activo', True)
        envio.fecha_modificacion = datetime.now()
        
        db.session.commit()
        
        # Recargar scheduler
        try:
            from scheduler_envios_programados import scheduler_global
            if scheduler_global:
                scheduler_global.detener_scheduler()
                scheduler_global.iniciar_scheduler()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'mensaje': 'Configuración actualizada'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error actualizando envío programado: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/config/envios/<int:id>', methods=['DELETE'])
def eliminar_envio_programado(id):
    """Elimina una configuración de PostgreSQL"""
    try:
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        db.session.delete(envio)
        db.session.commit()
        
        # Recargar scheduler
        try:
            from scheduler_envios_programados import scheduler_global
            if scheduler_global:
                scheduler_global.detener_scheduler()
                scheduler_global.iniciar_scheduler()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'mensaje': 'Configuración eliminada'
        })
        
    except Exception as e:
        logger.error(f"Error eliminando envío programado: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


# ========================================
# ENDPOINTS DE USUARIOS DE CAUSACIÓN
# ========================================

@dian_vs_erp_bp.route('/api/usuarios-causacion', methods=['GET'])
def obtener_usuarios_causacion():
    """Obtiene todos los usuarios de causación desde PostgreSQL"""
    try:
        usuarios_query = UsuarioCausacionDianVsErp.query.order_by(
            UsuarioCausacionDianVsErp.nombre_causador.asc()
        ).all()
        
        usuarios = [usuario.to_dict() for usuario in usuarios_query]
        
        return jsonify({
            'exito': True,
            'usuarios': usuarios
        })
        
    except Exception as e:
        current_app.logger.error(f"Error obteniendo usuarios causación: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/usuarios-causacion', methods=['POST'])
def crear_usuario_causacion():
    """Crea un nuevo usuario de causación"""
    inicio = datetime.now()
    try:
        from app import db as main_db
        data = request.json
        
        nuevo_usuario = UsuarioCausacionDianVsErp(
            nombre_causador=data['nombre_causador'],
            email=data['email'],
            activo=data.get('activo', True),
            usuario_creacion=session.get('usuario', 'sistema')
        )
        
        main_db.session.add(nuevo_usuario)
        main_db.session.commit()
        
        # 🆕 Registrar log de éxito con duración
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'SUCCESS',
            'CREAR_USUARIO_CAUSACION',
            f'Usuario de causación creado: {data["nombre_causador"]}',
            recurso_tipo='USUARIO',
            recurso_id=nuevo_usuario.id,
            duracion_ms=duracion_ms,
            detalles={'email': data['email'], 'activo': data.get('activo', True)}
        )
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario de causación creado',
            'id': nuevo_usuario.id
        })
        
    except Exception as e:
        main_db.session.rollback()
        
        # 🆕 Registrar log de error con stack trace
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'ERROR',
            'CREAR_USUARIO_CAUSACION',
            f'Error creando usuario de causación: {str(e)}',
            duracion_ms=duracion_ms,
            incluir_stacktrace=True
        )
        
        logger.error(f"Error creando usuario causación: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/usuarios-causacion/<int:id>', methods=['PUT'])
def actualizar_usuario_causacion(id):
    """Actualiza un usuario de causación"""
    inicio = datetime.now()
    try:
        from app import db as main_db
        
        data = request.json
        
        usuario = UsuarioCausacionDianVsErp.query.get(id)
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        # Guardar valores anteriores para el log
        valores_anteriores = {
            'nombre': usuario.nombre_causador,
            'email': usuario.email,
            'activo': usuario.activo
        }
        
        usuario.nombre_causador = data['nombre_causador']
        usuario.email = data['email']
        usuario.activo = data.get('activo', True)
        usuario.fecha_modificacion = datetime.now()
        usuario.usuario_modificacion = session.get('usuario', 'sistema')
        
        main_db.session.commit()
        
        # 🆕 Registrar log de actualización
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'SUCCESS',
            'ACTUALIZAR_USUARIO_CAUSACION',
            f'Usuario actualizado: {data["nombre_causador"]}',
            recurso_tipo='USUARIO',
            recurso_id=id,
            duracion_ms=duracion_ms,
            detalles={'anterior': valores_anteriores, 'nuevo': data}
        )
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario actualizado exitosamente'
        })
        
    except Exception as e:
        main_db.session.rollback()
        
        # 🆕 Registrar error
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'ERROR',
            'ACTUALIZAR_USUARIO_CAUSACION',
            f'Error actualizando usuario ID {id}: {str(e)}',
            recurso_tipo='USUARIO',
            recurso_id=id,
            duracion_ms=duracion_ms,
            incluir_stacktrace=True
        )
        
        logger.error(f"Error actualizando usuario causación: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/usuarios-causacion/<int:id>', methods=['DELETE'])
def eliminar_usuario_causacion(id):
    """Elimina un usuario de causación"""
    inicio = datetime.now()
    try:
        from app import db as main_db
        
        usuario = UsuarioCausacionDianVsErp.query.get(id)
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        # Guardar info antes de eliminar
        nombre_eliminado = usuario.nombre_causador
        email_eliminado = usuario.email
        
        main_db.session.delete(usuario)
        main_db.session.commit()
        
        # 🆕 Registrar eliminación
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'WARNING',
            'ELIMINAR_USUARIO_CAUSACION',
            f'Usuario eliminado: {nombre_eliminado}',
            recurso_tipo='USUARIO',
            recurso_id=id,
            duracion_ms=duracion_ms,
            detalles={'nombre': nombre_eliminado, 'email': email_eliminado}
        )
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario eliminado exitosamente'
        })
        
    except Exception as e:
        main_db.session.rollback()
        
        # 🆕 Registrar error
        duracion_ms = int((datetime.now() - inicio).total_seconds() * 1000)
        registrar_log(
            'ERROR',
            'ELIMINAR_USUARIO_CAUSACION',
            f'Error eliminando usuario ID {id}: {str(e)}',
            recurso_tipo='USUARIO',
            recurso_id=id,
            duracion_ms=duracion_ms,
            incluir_stacktrace=True
        )
        
        logger.error(f"Error eliminando usuario causación: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/causadores/disponibles', methods=['GET'])
def obtener_causadores_disponibles():
    """Obtiene lista de causadores únicos desde maestro_consolidado"""
    try:
        from app import db as main_db
        
        query = """
            SELECT DISTINCT SPLIT_PART(doc_causado_por, ' - ', 2) AS usuario_creacion
            FROM maestro_dian_vs_erp
            WHERE doc_causado_por IS NOT NULL
              AND doc_causado_por != ''
              AND SPLIT_PART(doc_causado_por, ' - ', 2) != ''
            ORDER BY usuario_creacion ASC
        """
        
        result = main_db.session.execute(main_db.text(query))
        causadores = [row[0] for row in result.fetchall()]
        
        return jsonify({
            'exito': True,
            'causadores': causadores
        })
        
    except Exception as e:
        logger.error(f"Error obteniendo causadores: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


# ========================================
# ENDPOINTS DE HISTORIAL
# ========================================

@dian_vs_erp_bp.route('/api/historial-envios', methods=['GET'])
def obtener_historial_envios():
    """Obtiene historial de envíos programados con filtros"""
    try:
        config_id = request.args.get('config_id', type=int)
        fecha_desde = request.args.get('fecha_desde')
        estado = request.args.get('estado')
        limit = request.args.get('limit', 50, type=int)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT h.id, h.configuracion_id, e.nombre as config_nombre,
                   h.fecha_ejecucion, h.documentos_procesados, h.documentos_enviados,
                   h.emails_enviados, h.emails_fallidos, h.estado, h.mensaje,
                   h.duracion_segundos
            FROM historial_envios_programados h
            LEFT JOIN envios_programados e ON h.configuracion_id = e.id
            WHERE 1=1
        """
        params = []
        
        if config_id:
            query += " AND h.configuracion_id = ?"
            params.append(config_id)
        
        if fecha_desde:
            query += " AND DATE(h.fecha_ejecucion) >= ?"
            params.append(fecha_desde)
        
        if estado:
            query += " AND h.estado = ?"
            params.append(estado)
        
        query += " ORDER BY h.fecha_ejecucion DESC LIMIT ?"
        params.append(limit)
        
        cursor.execute(query, params)
        
        historial = []
        for row in cursor.fetchall():
            historial.append({
                'id': row[0],
                'configuracion_id': row[1],
                'config_nombre': row[2],
                'fecha_ejecucion': row[3],
                'documentos_procesados': row[4],
                'documentos_enviados': row[5],
                'emails_enviados': row[6],
                'emails_fallidos': row[7],
                'estado': row[8],
                'mensaje': row[9],
                'duracion_segundos': row[10]
            })
        
        conn.close()
        
        return jsonify({
            'exito': True,
            'historial': historial
        })
        
    except Exception as e:
        logger.error(f"Error obteniendo historial: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error: {str(e)}'
        }), 500


# ================================
# ENDPOINTS DE LOGS DEL SISTEMA
# ================================

@dian_vs_erp_bp.route('/api/logs', methods=['GET'])
def obtener_logs_sistema():
    """Obtiene los logs del sistema con filtros"""
    try:
        fecha = request.args.get('fecha', date.today().isoformat())
        tipo = request.args.get('tipo', 'todos')
        
        # Datos de ejemplo de logs
        logs = [
            {
                'timestamp': '2025-11-30 10:30:15',
                'tipo': 'INFO',
                'modulo': 'ENVIO_EMAIL',
                'mensaje': 'Email enviado exitosamente a jperez@supertiendascanaveral.com - NIT: 805028041',
                'detalles': {'emails_enviados': 5, 'tiempo_proceso': '2.3s'}
            },
            {
                'timestamp': '2025-11-30 10:25:42',
                'tipo': 'WARNING',
                'modulo': 'SMTP',
                'mensaje': 'Conexión SMTP lenta - Tiempo de respuesta: 3.2s',
                'detalles': {'host': 'smtp.gmail.com', 'puerto': 587}
            },
            {
                'timestamp': '2025-11-30 10:20:08',
                'tipo': 'ERROR',
                'modulo': 'PROCESAMIENTO',
                'mensaje': 'Error procesando archivo DIAN - Formato inválido',
                'detalles': {'archivo': 'dian_facturas_20251130.xlsx', 'linea_error': 127}
            },
            {
                'timestamp': '2025-11-30 10:15:30',
                'tipo': 'SUCCESS',
                'modulo': 'CARGA_ARCHIVO',
                'mensaje': 'Archivo ERP cargado exitosamente',
                'detalles': {'archivo': 'erp_data_20251130.csv', 'registros': 15420}
            }
        ]
        
        # Filtrar por tipo si se especifica
        if tipo != 'todos':
            logs = [log for log in logs if log['tipo'].lower() == tipo.lower()]
        
        return jsonify({
            'exito': True,
            'fecha': fecha,
            'tipo_filtro': tipo,
            'logs': logs,
            'total': len(logs)
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo logs: {str(e)}'
        }), 500


# ================================
# ENDPOINTS ADICIONALES DE USUARIOS
# ================================

@dian_vs_erp_bp.route('/api/dian_usuarios/todos', methods=['GET'])
def obtener_todos_usuarios():
    """Obtiene todos los usuarios configurados agrupados por NIT"""
    try:
        # Datos de ejemplo de todos los usuarios
        usuarios_por_nit = [
            {
                'nit': '805028041',
                'razon_social': 'Supertiendas Cañaveral S.A.',
                'usuarios': [
                    {
                        'id': 1,
                        'nombres': 'Juan Carlos',
                        'apellidos': 'Pérez López',
                        'correo': 'jperez@supertiendascanaveral.com',
                        'tipo': 'SOLICITANTE',
                        'activo': True
                    },
                    {
                        'id': 2,
                        'nombres': 'María Elena',
                        'apellidos': 'Rodríguez Gómez',
                        'correo': 'mrodriguez@supertiendascanaveral.com',
                        'tipo': 'APROBADOR',
                        'activo': True
                    }
                ]
            },
            {
                'nit': '800123456',
                'razon_social': 'Empresa Ejemplo S.A.S.',
                'usuarios': [
                    {
                        'id': 3,
                        'nombres': 'Carlos Alberto',
                        'apellidos': 'López Martínez',
                        'correo': 'carlos@empresa.com',
                        'tipo': 'SOLICITANTE',
                        'activo': True
                    }
                ]
            }
        ]
        
        return jsonify({
            'exito': True,
            'usuarios_por_nit': usuarios_por_nit
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo usuarios: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/dian_usuarios/desactivar/<int:user_id>', methods=['POST'])
def desactivar_usuario(user_id):
    """Desactiva un usuario específico"""
    try:
        # En producción: actualizar estado en base de datos
        # Por ahora simular desactivación exitosa
        
        return jsonify({
            'exito': True,
            'mensaje': f'Usuario {user_id} desactivado correctamente'
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error desactivando usuario: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/dian_usuarios/eliminar/<int:user_id>', methods=['DELETE'])
def eliminar_usuario(user_id):
    """Elimina un usuario específico"""
    try:
        # En producción: eliminar de base de datos
        # Por ahora simular eliminación exitosa
        
        return jsonify({
            'exito': True,
            'mensaje': f'Usuario {user_id} eliminado correctamente'
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error eliminando usuario: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/logs/recientes', methods=['GET'])
def obtener_logs_recientes():
    """
    Obtiene los logs más recientes con filtros opcionales.
    
    Query params:
        limite (int): Cantidad máxima de logs (default: 100)
        nivel (str): Filtrar por nivel (SUCCESS, INFO, WARNING, ERROR, CRITICAL)
        operacion (str): Filtrar por tipo de operación
        usuario (str): Filtrar por usuario
    
    Returns:
        JSON con lista de logs y totales
    """
    try:
        # Obtener parámetros de consulta
        limite = int(request.args.get('limite', 100))
        nivel = request.args.get('nivel', None)
        operacion = request.args.get('operacion', None)
        usuario = request.args.get('usuario', None)
        
        # Usar helper para obtener logs
        logs = helper_obtener_logs(
            limite=limite,
            nivel=nivel,
            operacion=operacion,
            usuario=usuario
        )
        
        return jsonify({
            'exito': True,
            'logs': logs,
            'total': len(logs),
            'filtros': {
                'limite': limite,
                'nivel': nivel,
                'operacion': operacion,
                'usuario': usuario
            }
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo logs recientes: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/logs/filtrar', methods=['POST'])
def filtrar_logs_avanzado():
    """
    Filtrado avanzado de logs con rango de fechas y múltiples criterios.
    
    Body JSON:
        {
            "fecha_desde": "2025-12-01",
            "fecha_hasta": "2025-12-25",
            "nivel": "ERROR",
            "usuario": "admin",
            "nit": "900123456",
            "operacion": "ENVIO_EMAIL",
            "buscar_texto": "timeout",
            "limite": 200
        }
    
    Returns:
        JSON con logs filtrados y estadísticas
    """
    try:
        data = request.get_json()
        
        # Construir query base
        query = LogSistemaDianVsErp.query
        
        # Aplicar filtros
        if data.get('fecha_desde'):
            fecha_desde = datetime.strptime(data['fecha_desde'], '%Y-%m-%d').date()
            query = query.filter(LogSistemaDianVsErp.fecha >= fecha_desde)
        
        if data.get('fecha_hasta'):
            fecha_hasta = datetime.strptime(data['fecha_hasta'], '%Y-%m-%d').date()
            query = query.filter(LogSistemaDianVsErp.fecha <= fecha_hasta)
        
        if data.get('nivel'):
            query = query.filter_by(nivel=data['nivel'])
        
        if data.get('usuario'):
            query = query.filter(LogSistemaDianVsErp.usuario.ilike(f"%{data['usuario']}%"))
        
        if data.get('nit'):
            query = query.filter_by(nit_relacionado=data['nit'])
        
        if data.get('operacion'):
            query = query.filter_by(operacion=data['operacion'])
        
        if data.get('buscar_texto'):
            texto = f"%{data['buscar_texto']}%"
            query = query.filter(
                db.or_(
                    LogSistemaDianVsErp.mensaje.ilike(texto),
                    LogSistemaDianVsErp.detalles.ilike(texto)
                )
            )
        
        # Ordenar y limitar
        limite = data.get('limite', 200)
        logs_query = query.order_by(LogSistemaDianVsErp.timestamp.desc()).limit(limite).all()
        
        logs = [log.to_dict() for log in logs_query]
        
        # Obtener estadísticas del rango
        stats = {
            'total_encontrados': len(logs),
            'rango_fechas': {
                'desde': data.get('fecha_desde', 'N/A'),
                'hasta': data.get('fecha_hasta', 'N/A')
            }
        }
        
        # Registrar la búsqueda
        registrar_log(
            'INFO',
            'FILTRAR_LOGS',
            f'Búsqueda de logs: {len(logs)} resultados',
            detalles={'filtros': data}
        )
        
        return jsonify({
            'exito': True,
            'logs': logs,
            'estadisticas': stats
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error filtrando logs: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/logs/metricas', methods=['GET'])
def obtener_metricas_logs():
    """
    Obtiene métricas y estadísticas agregadas de logs.
    
    Query params:
        fecha_desde (str): Fecha inicio formato YYYY-MM-DD
        fecha_hasta (str): Fecha fin formato YYYY-MM-DD
    
    Returns:
        JSON con estadísticas detalladas:
        - Total de logs
        - Conteo por nivel (SUCCESS, INFO, WARNING, ERROR, CRITICAL)
        - Operaciones lentas (> 5 segundos)
        - Tasa de éxito
        - Top 5 operaciones
        - Top 5 usuarios más activos
    """
    try:
        from sqlalchemy import func
        
        # Obtener parámetros
        fecha_desde = request.args.get('fecha_desde')
        fecha_hasta = request.args.get('fecha_hasta')
        
        if fecha_desde:
            fecha_desde = datetime.strptime(fecha_desde, '%Y-%m-%d').date()
        if fecha_hasta:
            fecha_hasta = datetime.strptime(fecha_hasta, '%Y-%m-%d').date()
        
        # Obtener estadísticas básicas
        stats = obtener_estadisticas_logs(fecha_desde, fecha_hasta)
        
        # Top 5 operaciones más frecuentes
        query_top_ops = db.session.query(
            LogSistemaDianVsErp.operacion,
            func.count(LogSistemaDianVsErp.id).label('cantidad')
        )
        
        if fecha_desde:
            query_top_ops = query_top_ops.filter(LogSistemaDianVsErp.fecha >= fecha_desde)
        if fecha_hasta:
            query_top_ops = query_top_ops.filter(LogSistemaDianVsErp.fecha <= fecha_hasta)
        
        top_operaciones = [
            {'operacion': op, 'cantidad': cant}
            for op, cant in query_top_ops.group_by(LogSistemaDianVsErp.operacion).order_by(func.count(LogSistemaDianVsErp.id).desc()).limit(5).all()
        ]
        
        # Top 5 usuarios más activos
        query_top_users = db.session.query(
            LogSistemaDianVsErp.usuario,
            func.count(LogSistemaDianVsErp.id).label('cantidad')
        ).filter(LogSistemaDianVsErp.usuario.isnot(None))
        
        if fecha_desde:
            query_top_users = query_top_users.filter(LogSistemaDianVsErp.fecha >= fecha_desde)
        if fecha_hasta:
            query_top_users = query_top_users.filter(LogSistemaDianVsErp.fecha <= fecha_hasta)
        
        top_usuarios = [
            {'usuario': usr, 'cantidad': cant}
            for usr, cant in query_top_users.group_by(LogSistemaDianVsErp.usuario).order_by(func.count(LogSistemaDianVsErp.id).desc()).limit(5).all()
        ]
        
        # Combinar todo
        stats['top_operaciones'] = top_operaciones
        stats['top_usuarios'] = top_usuarios
        
        return jsonify({
            'exito': True,
            'metricas': stats
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo métricas: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/logs/exportar', methods=['POST'])
def exportar_logs_excel():
    """
    Exporta logs filtrados a Excel.
    
    Body JSON: mismos filtros que /api/logs/filtrar
    
    Returns:
        Archivo Excel con logs
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        
        data = request.get_json()
        
        # Reutilizar lógica de filtrado (mismo código que filtrar_logs_avanzado)
        query = LogSistemaDianVsErp.query
        
        if data.get('fecha_desde'):
            fecha_desde = datetime.strptime(data['fecha_desde'], '%Y-%m-%d').date()
            query = query.filter(LogSistemaDianVsErp.fecha >= fecha_desde)
        
        if data.get('fecha_hasta'):
            fecha_hasta = datetime.strptime(data['fecha_hasta'], '%Y-%m-%d').date()
            query = query.filter(LogSistemaDianVsErp.fecha <= fecha_hasta)
        
        if data.get('nivel'):
            query = query.filter_by(nivel=data['nivel'])
        
        if data.get('usuario'):
            query = query.filter(LogSistemaDianVsErp.usuario.ilike(f"%{data['usuario']}%"))
        
        if data.get('nit'):
            query = query.filter_by(nit_relacionado=data['nit'])
        
        if data.get('operacion'):
            query = query.filter_by(operacion=data['operacion'])
        
        # Obtener logs (sin límite para exportación)
        logs = query.order_by(LogSistemaDianVsErp.timestamp.desc()).all()
        
        # Crear Excel
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Logs Sistema"
        
        # Encabezados
        headers = ['ID', 'Fecha', 'Hora', 'Nivel', 'Usuario', 'IP', 'NIT', 'Empresa', 'Operación', 'Mensaje', 'Duración (ms)']
        ws.append(headers)
        
        # Estilo de encabezados
        header_fill = PatternFill(start_color="166534", end_color="166534", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Datos
        for log in logs:
            ws.append([
                log.id,
                log.fecha.strftime('%Y-%m-%d') if log.fecha else '',
                log.timestamp.strftime('%H:%M:%S') if log.timestamp else '',
                log.nivel,
                log.usuario or '',
                log.ip_origen or '',
                log.nit_relacionado or '',
                log.empresa_relacionada or '',
                log.operacion or '',
                log.mensaje,
                log.duracion_ms or ''
            ])
        
        # Ajustar anchos de columna
        for column in ws.columns:
            max_length = 0
            column = [cell for cell in column]
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column[0].column_letter].width = adjusted_width
        
        # Guardar a BytesIO
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Registrar exportación
        registrar_log(
            'SUCCESS',
            'EXPORTAR_LOGS',
            f'Logs exportados a Excel: {len(logs)} registros',
            detalles={'filtros': data}
        )
        
        filename = f'logs_dian_vs_erp_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error exportando logs: {str(e)}'
        }), 500


# ============================================
# ENDPOINTS DE USUARIOS ASIGNADOS POR NIT
# ============================================

@dian_vs_erp_bp.route('/api/usuarios/todos', methods=['GET'])
def api_usuarios_todos():
    """Obtener todos los usuarios asignados a NITs"""
    try:
        from app import db as main_db
        
        # Query para obtener todos los usuarios
        query = """
            SELECT id, nit, razon_social, tipo_usuario, nombres, apellidos, 
                   correo, telefono, activo, fecha_creacion
            FROM usuarios_asignados
            ORDER BY nit, tipo_usuario, apellidos
        """
        
        result = main_db.session.execute(main_db.text(query))
        usuarios = []
        
        for row in result:
            usuarios.append({
                'usuario_id': row[0],
                'nit': row[1],
                'razon_social': row[2],
                'tipo_usuario': row[3],
                'nombres': row[4],
                'apellidos': row[5],
                'correo': row[6],
                'telefono': row[7],
                'activo': row[8],
                'fecha_creacion': row[9].isoformat() if row[9] else None
            })
        
        return jsonify({
            'exito': True,
            'usuarios': usuarios,
            'total': len(usuarios)
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo usuarios: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios/por_nit/<nit>', methods=['GET'])
def api_usuarios_por_nit(nit):
    """Obtener usuarios de un NIT específico"""
    try:
        from app import db as main_db
        
        query = """
            SELECT id, nit, razon_social, tipo_usuario, nombres, apellidos, 
                   correo, telefono, activo, fecha_creacion
            FROM usuarios_asignados
            WHERE nit = :nit
            ORDER BY tipo_usuario, apellidos
        """
        
        result = main_db.session.execute(main_db.text(query), {'nit': nit})
        usuarios = []
        
        for row in result:
            usuarios.append({
                'usuario_id': row[0],
                'nit': row[1],
                'razon_social': row[2],
                'tipo_usuario': row[3],
                'nombres': row[4],
                'apellidos': row[5],
                'correo': row[6],
                'telefono': row[7],
                'activo': row[8],
                'fecha_creacion': row[9].isoformat() if row[9] else None
            })
        
        return jsonify({
            'exito': True,
            'usuarios': usuarios,
            'total': len(usuarios)
        })
        
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo usuarios del NIT {nit}: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios/agregar', methods=['POST'])
def api_usuarios_agregar():
    """Agregar un nuevo usuario asociado a un NIT"""
    try:
        from app import db as main_db
        import re
        
        datos = request.get_json()
        
        # Validaciones
        nit = datos.get('nit', '').strip()
        razon_social = datos.get('razon_social', '').strip()
        tipo_usuario = datos.get('tipo_usuario', '').upper()
        nombres = datos.get('nombres', '').strip()
        apellidos = datos.get('apellidos', '').strip()
        correo = datos.get('correo', '').strip().lower()
        telefono = datos.get('telefono', '').strip()
        
        if not nit:
            return jsonify({'exito': False, 'mensaje': 'NIT es requerido'}), 400
        
        if tipo_usuario not in ['SOLICITANTE', 'APROBADOR']:
            return jsonify({'exito': False, 'mensaje': 'Tipo de usuario inválido'}), 400
        
        if not nombres or not apellidos:
            return jsonify({'exito': False, 'mensaje': 'Nombres y apellidos son requeridos'}), 400
        
        # Validar email
        patron_email = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(patron_email, correo):
            return jsonify({'exito': False, 'mensaje': 'Email no válido'}), 400
        
        # Insertar usuario
        query = """
            INSERT INTO usuarios_asignados 
            (nit, razon_social, tipo_usuario, nombres, apellidos, correo, telefono, activo)
            VALUES (:nit, :razon_social, :tipo_usuario, :nombres, :apellidos, :correo, :telefono, TRUE)
        """
        
        main_db.session.execute(main_db.text(query), {
            'nit': nit,
            'razon_social': razon_social,
            'tipo_usuario': tipo_usuario,
            'nombres': nombres,
            'apellidos': apellidos,
            'correo': correo,
            'telefono': telefono
        })
        
        main_db.session.commit()
        
        return jsonify({
            'exito': True,
            'mensaje': f'Usuario {nombres} {apellidos} agregado exitosamente'
        })
        
    except Exception as e:
        main_db.session.rollback()
        
        # Verificar si es error de duplicado
        if 'duplicate' in str(e).lower() or 'unique' in str(e).lower():
            return jsonify({
                'exito': False,
                'mensaje': 'Ya existe un usuario con ese correo y tipo para este NIT'
            }), 400
        
        return jsonify({
            'exito': False,
            'mensaje': f'Error agregando usuario: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios/desactivar/<int:id>', methods=['POST'])
def api_usuarios_desactivar(id):
    """Desactivar (eliminar lógicamente) un usuario"""
    try:
        from app import db as main_db
        
        query = """
            UPDATE usuarios_asignados 
            SET activo = FALSE, fecha_modificacion = CURRENT_TIMESTAMP
            WHERE id = :id
        """
        
        result = main_db.session.execute(main_db.text(query), {'id': id})
        main_db.session.commit()
        
        if result.rowcount == 0:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario desactivado correctamente'
        })
        
    except Exception as e:
        from app import db as main_db
        main_db.session.rollback()
        print(f"ERROR desactivar usuario: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error al desactivar usuario: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/usuarios/obtener/<int:id>', methods=['GET'])
def api_usuarios_obtener(id):
    """Obtener datos de un usuario específico para edición"""
    try:
        from app import db as main_db
        
        query = """
            SELECT 
                id as usuario_id,
                nit,
                razon_social,
                tipo_usuario,
                nombres,
                apellidos,
                correo,
                telefono,
                activo
            FROM usuarios_asignados 
            WHERE id = :id
        """
        
        result = main_db.session.execute(main_db.text(query), {'id': id})
        usuario = result.fetchone()
        
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        return jsonify({
            'exito': True,
            'usuario': dict(usuario._mapping)
        })
        
    except Exception as e:
        print(f"ERROR obtener usuario: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error al obtener usuario: {str(e)}'
        }), 500


@dian_vs_erp_bp.route('/api/usuarios/editar/<int:id>', methods=['PUT'])
def api_usuarios_editar(id):
    """Editar datos de un usuario existente"""
    try:
        from app import db as main_db
        data = request.get_json()
        
        # Validaciones
        if not data.get('nombres') or not data.get('apellidos') or not data.get('correo'):
            return jsonify({
                'exito': False,
                'mensaje': 'Faltan campos obligatorios'
            }), 400
        
        query = """
            UPDATE usuarios_asignados 
            SET 
                razon_social = :razon_social,
                tipo_usuario = :tipo_usuario,
                nombres = :nombres,
                apellidos = :apellidos,
                correo = :correo,
                telefono = :telefono,
                fecha_modificacion = CURRENT_TIMESTAMP
            WHERE id = :id
        """
        
        result = main_db.session.execute(main_db.text(query), {
            'id': id,
            'razon_social': data.get('razon_social'),
            'tipo_usuario': data.get('tipo_usuario'),
            'nombres': data.get('nombres'),
            'apellidos': data.get('apellidos'),
            'correo': data.get('correo'),
            'telefono': data.get('telefono')
        })
        
        main_db.session.commit()
        
        if result.rowcount == 0:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario actualizado correctamente'
        })
        
    except Exception as e:
        from app import db as main_db
        main_db.session.rollback()
        print(f"ERROR editar usuario: {e}")
        return jsonify({
            'exito': False,
            'mensaje': f'Error al actualizar usuario: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios/activar/<int:id>', methods=['POST'])
def api_usuarios_activar(id):
    """Activar un usuario desactivado"""
    try:
        from app import db as main_db
        
        query = """
            UPDATE usuarios_asignados 
            SET activo = TRUE, fecha_modificacion = CURRENT_TIMESTAMP
            WHERE id = :id
        """
        
        result = main_db.session.execute(main_db.text(query), {'id': id})
        main_db.session.commit()
        
        if result.rowcount == 0:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario activado exitosamente'
        })
        
    except Exception as e:
        main_db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error activando usuario: {str(e)}'
        }), 500


# ========================================
# FIN DE ENDPOINTS ACTIVOS
# NOTA: Se eliminaron endpoints duplicados que causaban conflictos
# Los endpoints correctos están arriba (líneas 1187-1510)
# ========================================
        import json
        from modules.dian_vs_erp.scheduler_envios import reiniciar_scheduler_dian_vs_erp
        
        data = request.json
        usuario_sesion = session.get('usuario', 'WEB')
        
        # Validar campos requeridos
        if not data.get('nombre') or not data.get('tipo') or not data.get('hora_envio') or not data.get('frecuencia'):
            return jsonify({
                'exito': False,
                'mensaje': 'Faltan campos requeridos: nombre, tipo, hora_envio, frecuencia'
            }), 400
        
        # Crear configuración
        envio = EnvioProgramadoDianVsErp(
            nombre=data['nombre'].strip(),
            tipo=data['tipo'],
            dias_minimos=data.get('dias_minimos', 3),
            requiere_acuses_minimo=data.get('requiere_acuses_minimo', 2),
            estados_incluidos=data.get('estados_incluidos'),
            estados_excluidos=json.dumps(data.get('estados_excluidos', [])),
            hora_envio=data['hora_envio'],
            frecuencia=data['frecuencia'],
            dias_semana=json.dumps(data.get('dias_semana', [])),
            tipo_destinatario=data.get('tipo_destinatario'),
            email_cc=data.get('email_cc'),
            activo=data.get('activo', True),
            usuario_creacion=usuario_sesion
        )
        
        # Calcular próximo envío
        from modules.dian_vs_erp.scheduler_envios import scheduler_dian_vs_erp_global
        if scheduler_dian_vs_erp_global:
            envio.proximo_envio = scheduler_dian_vs_erp_global._calcular_proximo_envio(envio)
        
        db.session.add(envio)
        db.session.commit()
        
        # Reiniciar scheduler para cargar la nueva configuración
        try:
            reiniciar_scheduler_dian_vs_erp()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'id': envio.id,
            'mensaje': 'Configuración creada exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error creando configuración: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/config/envios/<int:id>', methods=['PUT'])
def api_envios_actualizar(id):
    """Actualizar una configuración existente"""
    try:
        import json
        from modules.dian_vs_erp.scheduler_envios import reiniciar_scheduler_dian_vs_erp
        
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        data = request.json
        usuario_sesion = session.get('usuario', 'WEB')
        
        # Actualizar campos
        if 'nombre' in data:
            envio.nombre = data['nombre'].strip()
        if 'tipo' in data:
            envio.tipo = data['tipo']
        if 'dias_minimos' in data:
            envio.dias_minimos = data['dias_minimos']
        if 'requiere_acuses_minimo' in data:
            envio.requiere_acuses_minimo = data['requiere_acuses_minimo']
        if 'estados_excluidos' in data:
            envio.estados_excluidos = json.dumps(data['estados_excluidos'])
        if 'hora_envio' in data:
            envio.hora_envio = data['hora_envio']
        if 'frecuencia' in data:
            envio.frecuencia = data['frecuencia']
        if 'dias_semana' in data:
            envio.dias_semana = json.dumps(data['dias_semana'])
        if 'activo' in data:
            envio.activo = data['activo']
        
        envio.usuario_modificacion = usuario_sesion
        envio.fecha_modificacion = datetime.now()
        
        db.session.commit()
        
        # Reiniciar scheduler
        try:
            reiniciar_scheduler_dian_vs_erp()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'mensaje': 'Configuración actualizada exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error actualizando configuración: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/config/envios/<int:id>', methods=['DELETE'])
def api_envios_eliminar(id):
    """Eliminar una configuración"""
    try:
        from modules.dian_vs_erp.scheduler_envios import reiniciar_scheduler_dian_vs_erp
        
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        db.session.delete(envio)
        db.session.commit()
        
        # Reiniciar scheduler
        try:
            reiniciar_scheduler_dian_vs_erp()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'mensaje': 'Configuración eliminada exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error eliminando configuración: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/config/envios/<int:id>/ejecutar', methods=['POST'])
def api_envios_ejecutar_manual(id):
    """Ejecutar manualmente un envío (para pruebas)"""
    try:
        from modules.dian_vs_erp.scheduler_envios import scheduler_dian_vs_erp_global
        
        if not scheduler_dian_vs_erp_global:
            return jsonify({
                'exito': False,
                'mensaje': 'Scheduler no está iniciado'
            }), 500
        
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        # Ejecutar en segundo plano para no bloquear la respuesta
        import threading
        thread = threading.Thread(
            target=scheduler_dian_vs_erp_global.ejecutar_envio_programado,
            args=(id,)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'exito': True,
            'mensaje': 'Ejecución iniciada. Revise el historial en unos momentos.'
        })
    
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error ejecutando envío: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/config/envios/<int:id>/toggle', methods=['POST'])
def api_envios_toggle(id):
    """Activar/Desactivar una configuración"""
    try:
        from modules.dian_vs_erp.scheduler_envios import reiniciar_scheduler_dian_vs_erp
        
        envio = EnvioProgramadoDianVsErp.query.get(id)
        if not envio:
            return jsonify({
                'exito': False,
                'mensaje': 'Configuración no encontrada'
            }), 404
        
        envio.activo = not envio.activo
        envio.fecha_modificacion = datetime.now()
        envio.usuario_modificacion = session.get('usuario', 'WEB')
        
        db.session.commit()
        
        # Reiniciar scheduler
        try:
            reiniciar_scheduler_dian_vs_erp()
        except:
            pass
        
        return jsonify({
            'exito': True,
            'activo': envio.activo,
            'mensaje': f'Configuración {"activada" if envio.activo else "desactivada"} exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error cambiando estado: {str(e)}'
        }), 500


# ========================================
# ENDPOINTS - USUARIOS DE CAUSACIÓN
# ========================================

@dian_vs_erp_bp.route('/api/usuarios-causacion', methods=['GET'])
def api_usuarios_causacion_get():
    """Obtener todos los usuarios de causación"""
    try:
        usuarios = UsuarioCausacionDianVsErp.query.order_by(
            UsuarioCausacionDianVsErp.nombre_causador.asc()
        ).all()
        
        return jsonify({
            'exito': True,
            'usuarios': [u.to_dict() for u in usuarios]
        })
    
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo usuarios: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios-causacion', methods=['POST'])
def api_usuarios_causacion_crear():
    """Crear un nuevo usuario de causación"""
    try:
        data = request.json
        usuario_sesion = session.get('usuario', 'WEB')
        
        # Validar campos requeridos
        if not data.get('nombre_causador') or not data.get('email'):
            return jsonify({
                'exito': False,
                'mensaje': 'Faltan campos requeridos: nombre_causador, email'
            }), 400
        
        # Validar que no exista
        existe = UsuarioCausacionDianVsErp.query.filter_by(
            nombre_causador=data['nombre_causador'].strip().upper()
        ).first()
        
        if existe:
            return jsonify({
                'exito': False,
                'mensaje': 'Ya existe un usuario con ese nombre'
            }), 400
        
        # Crear usuario
        usuario = UsuarioCausacionDianVsErp(
            nombre_causador=data['nombre_causador'].strip().upper(),
            email=data['email'].strip().lower(),
            activo=data.get('activo', True),
            usuario_creacion=usuario_sesion
        )
        
        db.session.add(usuario)
        db.session.commit()
        
        return jsonify({
            'exito': True,
            'id': usuario.id,
            'mensaje': 'Usuario de causación creado exitosamente',
            'usuario': usuario.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error creando usuario: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios-causacion/<int:id>', methods=['PUT'])
def api_usuarios_causacion_actualizar(id):
    """Actualizar un usuario de causación"""
    try:
        usuario = UsuarioCausacionDianVsErp.query.get(id)
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        data = request.json
        usuario_sesion = session.get('usuario', 'WEB')
        
        # Actualizar campos
        if 'nombre_causador' in data:
            # Verificar que el nuevo nombre no exista en otro registro
            nuevo_nombre = data['nombre_causador'].strip().upper()
            if nuevo_nombre != usuario.nombre_causador:
                existe = UsuarioCausacionDianVsErp.query.filter(
                    UsuarioCausacionDianVsErp.nombre_causador == nuevo_nombre,
                    UsuarioCausacionDianVsErp.id != id
                ).first()
                
                if existe:
                    return jsonify({
                        'exito': False,
                        'mensaje': 'Ya existe un usuario con ese nombre'
                    }), 400
                
                usuario.nombre_causador = nuevo_nombre
        
        if 'email' in data:
            usuario.email = data['email'].strip().lower()
        
        if 'activo' in data:
            usuario.activo = data['activo']
        
        usuario.usuario_modificacion = usuario_sesion
        usuario.fecha_modificacion = datetime.now()
        
        db.session.commit()
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario actualizado exitosamente',
            'usuario': usuario.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error actualizando usuario: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios-causacion/<int:id>', methods=['DELETE'])
def api_usuarios_causacion_eliminar(id):
    """Eliminar un usuario de causación"""
    try:
        usuario = UsuarioCausacionDianVsErp.query.get(id)
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        # Verificar si tiene documentos asociados
        if usuario.total_documentos and usuario.total_documentos > 0:
            return jsonify({
                'exito': False,
                'mensaje': f'No se puede eliminar. Este usuario tiene {usuario.total_documentos} documentos asociados. Desactívelo en su lugar.'
            }), 400
        
        db.session.delete(usuario)
        db.session.commit()
        
        return jsonify({
            'exito': True,
            'mensaje': 'Usuario eliminado exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error eliminando usuario: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/usuarios-causacion/<int:id>/toggle', methods=['POST'])
def api_usuarios_causacion_toggle(id):
    """Activar/Desactivar un usuario de causación"""
    try:
        usuario = UsuarioCausacionDianVsErp.query.get(id)
        if not usuario:
            return jsonify({
                'exito': False,
                'mensaje': 'Usuario no encontrado'
            }), 404
        
        usuario.activo = not usuario.activo
        usuario.fecha_modificacion = datetime.now()
        usuario.usuario_modificacion = session.get('usuario', 'WEB')
        
        db.session.commit()
        
        return jsonify({
            'exito': True,
            'activo': usuario.activo,
            'mensaje': f'Usuario {"activado" if usuario.activo else "desactivado"} exitosamente'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'exito': False,
            'mensaje': f'Error cambiando estado: {str(e)}'
        }), 500

@dian_vs_erp_bp.route('/api/causadores/disponibles', methods=['GET'])
def api_causadores_disponibles():
    """Obtener lista de causadores disponibles desde la tabla maestro"""
    try:
        # Obtener causadores únicos de la tabla maestro
        causadores = db.session.query(MaestroDianVsErp.doc_causado_por).filter(
            MaestroDianVsErp.doc_causado_por.isnot(None),
            MaestroDianVsErp.doc_causado_por != ''
        ).distinct().order_by(MaestroDianVsErp.doc_causado_por).all()
        
        lista_causadores = [c[0] for c in causadores if c[0]]
        
        return jsonify({
            'exito': True,
            'causadores': lista_causadores
        })
    
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo causadores: {str(e)}'
        }), 500


# ========================================
# ENDPOINTS - HISTORIAL DE ENVÍOS
# ========================================

@dian_vs_erp_bp.route('/api/historial-envios', methods=['GET'])
def api_historial_envios():
    """Obtener el historial de envíos programados"""
    try:
        config_id = request.args.get('configuracion_id', type=int)
        limite = request.args.get('limite', 50, type=int)
        
        query = HistorialEnvioDianVsErp.query
        
        if config_id:
            query = query.filter_by(configuracion_id=config_id)
        
        historiales = query.order_by(
            HistorialEnvioDianVsErp.fecha_ejecucion.desc()
        ).limit(limite).all()
        
        # Incluir nombre de la configuración
        resultados = []
        for h in historiales:
            h_dict = h.to_dict()
            config = EnvioProgramadoDianVsErp.query.get(h.configuracion_id)
            h_dict['nombre_config'] = config.nombre if config else 'Configuración eliminada'
            resultados.append(h_dict)
        
        return jsonify({
            'exito': True,
            'historial': resultados
        })
    
    except Exception as e:
        return jsonify({
            'exito': False,
            'mensaje': f'Error obteniendo historial: {str(e)}'
        }), 500

# ========================================
# ENDPOINTS - SINCRONIZACI�N
# ========================================

@dian_vs_erp_bp.route('/api/sincronizar', methods=['POST'])
def api_sincronizar():
    from datetime import datetime
    fecha_actual = datetime.now()
    return jsonify({'exito': True, 'mensaje': 'Sincronizado', 'fecha_sincronizacion': fecha_actual.strftime('%d/%m/%Y %H:%M:%S')})

