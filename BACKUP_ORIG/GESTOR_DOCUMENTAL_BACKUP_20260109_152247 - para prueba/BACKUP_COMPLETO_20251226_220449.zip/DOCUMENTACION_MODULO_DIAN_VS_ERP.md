# 📋 DOCUMENTACIÓN COMPLETA - MÓDULO DIAN VS ERP
**Sistema de Envíos Programados Automáticos**  
**Fecha de Documentación:** 26 de Diciembre de 2025  
**Estado:** ✅ FUNCIONAL Y PRODUCTIVO

---

## 📑 ÍNDICE
1. [Descripción General](#descripción-general)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Base de Datos](#base-de-datos)
4. [Sistema de Envíos Programados](#sistema-de-envíos-programados)
5. [Generación de Excel Adjunto](#generación-de-excel-adjunto)
6. [Flujos de Trabajo](#flujos-de-trabajo)
7. [Configuración y Uso](#configuración-y-uso)
8. [Troubleshooting](#troubleshooting)

---

## 📖 DESCRIPCIÓN GENERAL

El **Módulo DIAN vs ERP** es un sistema automatizado que monitorea facturas electrónicas recibidas desde la DIAN y envía alertas por correo electrónico cuando los documentos cumplen ciertos criterios (días pendientes, falta de acuses, etc.).

### Características Principales
- ✅ **Envíos programados automáticos** con APScheduler
- ✅ **Filtros configurables** por días, estados, acuses
- ✅ **Emails consolidados** con HTML profesional
- ✅ **Excel adjunto** cuando hay más de 50 documentos
- ✅ **Hipervínculos a DIAN** en Excel para ver documentos
- ✅ **Ordenamiento inteligente** (más antiguo primero)
- ✅ **Usuarios por NIT** para envíos dirigidos
- ✅ **Logs completos** de auditoría

---

## 🏗️ ARQUITECTURA DEL SISTEMA

### Estructura de Archivos
```
modules/dian_vs_erp/
├── __init__.py                 # Inicialización del blueprint
├── models.py                   # Modelos SQLAlchemy (5 tablas)
├── routes.py                   # Endpoints HTTP (30+ endpoints)
├── scheduler_envios.py         # Sistema de envíos programados ⭐
└── backend_relaciones.py       # Backend secundario (puerto 5002)

templates/dian_vs_erp/
├── visor_dian_v2.html         # Interfaz principal del visor
├── configuracion.html          # Configuración de envíos programados
└── recepcion_digital.html      # Recepción de relaciones

sql/
└── dian_vs_erp_schema.sql     # Schema de base de datos
```

### Tecnologías Utilizadas
- **Backend:** Flask 3.0 + SQLAlchemy 2.0 + PostgreSQL 18
- **Scheduler:** APScheduler 3.x (BackgroundScheduler)
- **Email:** Flask-Mail + SMTP (Gmail/Zimbra)
- **Excel:** openpyxl 3.1.2
- **Frontend:** Tabulator.js 5.5.2 + JavaScript vanilla

---

## 🗄️ BASE DE DATOS

### Tabla: `maestro_dian_vs_erp`
**Descripción:** Maestro de todos los documentos electrónicos recibidos desde la DIAN.

```sql
CREATE TABLE maestro_dian_vs_erp (
    id SERIAL PRIMARY KEY,
    nit_emisor VARCHAR(20),
    razon_social VARCHAR(255),
    prefijo VARCHAR(10),
    folio VARCHAR(20),
    cufe TEXT,  -- CUFE del documento
    fecha_emision TIMESTAMP,
    valor NUMERIC(15,2),
    estado_aprobacion VARCHAR(50),  -- 'Pendiente', 'Causada', 'Recibida', etc.
    dias_desde_emision INTEGER,     -- Calculado automáticamente
    acuses_recibidos INTEGER DEFAULT 0,
    acuses_requeridos INTEGER DEFAULT 3,
    fecha_creacion TIMESTAMP DEFAULT NOW(),
    fecha_actualizacion TIMESTAMP
);

CREATE INDEX idx_dias_emision ON maestro_dian_vs_erp(dias_desde_emision);
CREATE INDEX idx_estado ON maestro_dian_vs_erp(estado_aprobacion);
CREATE INDEX idx_nit_emisor ON maestro_dian_vs_erp(nit_emisor);
```

### Tabla: `envios_programados_dian_vs_erp`
**Descripción:** Configuraciones de envíos automáticos programados.

```sql
CREATE TABLE envios_programados_dian_vs_erp (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,           -- Nombre descriptivo del envío
    tipo_envio VARCHAR(50),                 -- 'PENDIENTES_DIAS' o 'CREDITO_SIN_ACUSES'
    dias_minimos INTEGER,                   -- Mínimo de días para incluir documento
    estados_excluidos TEXT,                 -- JSON: ["Causada", "Recibida"]
    frecuencia VARCHAR(20),                 -- 'DIARIO' o 'SEMANAL'
    hora_envio VARCHAR(5),                  -- Formato: '08:00', '14:00'
    dias_semana TEXT,                       -- JSON: [1,2,3,4,5] (Lun-Vie)
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT NOW()
);
```

**Ejemplos de configuraciones:**
```json
// 1. Documentos pendientes +3 días (diario a las 08:00)
{
  "nombre": "Documentos pendientes +3 días",
  "tipo_envio": "PENDIENTES_DIAS",
  "dias_minimos": 3,
  "estados_excluidos": ["Causada", "Recibida"],
  "frecuencia": "DIARIO",
  "hora_envio": "08:00"
}

// 2. Alerta sin causar 5 días (diario a las 08:00)
{
  "nombre": "Alerta sin causar 5 dias",
  "tipo_envio": "PENDIENTES_DIAS",
  "dias_minimos": 5,
  "estados_excluidos": ["Causada"],
  "frecuencia": "DIARIO",
  "hora_envio": "08:00"
}

// 3. Crédito sin acuses completos (diario a las 14:00)
{
  "nombre": "Crédito sin acuses completos",
  "tipo_envio": "CREDITO_SIN_ACUSES",
  "acuses_minimos": 2,
  "estados_excluidos": null,
  "frecuencia": "DIARIO",
  "hora_envio": "14:00"
}
```

### Tabla: `usuarios_asignados`
**Descripción:** Usuarios que recibirán los correos, asociados por NIT.

```sql
CREATE TABLE usuarios_asignados (
    id SERIAL PRIMARY KEY,
    nit VARCHAR(20) NOT NULL,               -- NIT del tercero
    razon_social VARCHAR(255),
    tipo_usuario VARCHAR(50),               -- 'APROBADOR', 'SOLICITANTE'
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    correo VARCHAR(255) NOT NULL,           -- Email destino ⭐
    telefono VARCHAR(20),
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT NOW(),
    fecha_modificacion TIMESTAMP
);

CREATE INDEX idx_nit_activo ON usuarios_asignados(nit, activo);
```

**Ejemplo de registro:**
```sql
INSERT INTO usuarios_asignados (nit, razon_social, nombres, apellidos, correo, tipo_usuario)
VALUES ('805013653', 'LA GALERIA Y CIA SAS', 'RICARDO', 'RIASCOS BURGOS', 
        'ricardoriascos07@gmail.com', 'APROBADOR');
```

### Tabla: `historial_envios_dian_vs_erp`
**Descripción:** Auditoría completa de todos los envíos ejecutados.

```sql
CREATE TABLE historial_envios_dian_vs_erp (
    id SERIAL PRIMARY KEY,
    envio_programado_id INTEGER REFERENCES envios_programados_dian_vs_erp(id),
    fecha_ejecucion TIMESTAMP DEFAULT NOW(),
    estado VARCHAR(20),                     -- 'EXITOSO', 'FALLIDO', 'PARCIAL'
    docs_procesados INTEGER,
    docs_enviados INTEGER,
    emails_enviados INTEGER,
    emails_fallidos INTEGER,
    tiempo_ejecucion NUMERIC(10,2),         -- Segundos
    detalles TEXT                           -- JSON con información adicional
);
```

### Tabla: `usuarios_causacion_dian_vs_erp`
**Descripción:** Usuarios específicos para causación de documentos.

```sql
CREATE TABLE usuarios_causacion_dian_vs_erp (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(255) NOT NULL UNIQUE,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT NOW()
);
```

---

## 📧 SISTEMA DE ENVÍOS PROGRAMADOS

### Clase Principal: `EnviosProgramadosSchedulerDianVsErp`

**Ubicación:** `modules/dian_vs_erp/scheduler_envios.py` (594 líneas)

#### Inicialización
```python
class EnviosProgramadosSchedulerDianVsErp:
    def __init__(self, app=None):
        self.scheduler = BackgroundScheduler()
        self.app = app
        self.smtp_config = {
            'server': os.getenv('MAIL_SERVER', 'smtp.gmail.com'),
            'port': int(os.getenv('MAIL_PORT', 465)),
            'username': os.getenv('MAIL_USERNAME'),
            'password': os.getenv('MAIL_PASSWORD'),
            'use_ssl': os.getenv('MAIL_USE_SSL', 'True') == 'True',
            'use_tls': os.getenv('MAIL_USE_TLS', 'False') == 'True'
        }
```

#### Métodos Principales

##### 1. `iniciar_scheduler()`
**Propósito:** Inicia el scheduler con todas las configuraciones activas.

```python
def iniciar_scheduler(self):
    """
    - Carga configuraciones activas desde base de datos
    - Crea triggers cron basados en frecuencia (DIARIO/SEMANAL)
    - Agrega jobs al scheduler
    - Inicia el scheduler en background
    """
```

**Logs generados:**
```
INFO:modules.dian_vs_erp.scheduler_envios:📋 Cargadas 5 configuraciones activas
INFO:modules.dian_vs_erp.scheduler_envios:✅ Job agregado: Documentos pendientes +3 días (08:00)
INFO:modules.dian_vs_erp.scheduler_envios:✅ Job agregado: Alerta sin causar 5 dias (08:00)
INFO:modules.dian_vs_erp.scheduler_envios:🚀 Scheduler DIAN VS ERP iniciado
```

##### 2. `ejecutar_envio_programado(config_id)`
**Propósito:** Ejecuta un envío específico (manual o programado).

**Flujo:**
1. Consulta configuración por ID
2. Determina tipo de envío (PENDIENTES_DIAS o CREDITO_SIN_ACUSES)
3. Llama al método procesador correspondiente
4. Registra resultado en historial
5. Calcula próxima ejecución

##### 3. `_procesar_pendientes_dias(config)`
**Propósito:** Procesa documentos con días pendientes >= mínimo configurado.

**Lógica:**
```python
def _procesar_pendientes_dias(self, config):
    # 1. Query documentos ORDENADOS por días (más antiguo primero)
    query = MaestroDianVsErp.query.filter(
        MaestroDianVsErp.dias_desde_emision >= config.dias_minimos
    )
    
    # 2. Excluir estados configurados
    if config.estados_excluidos:
        estados = json.loads(config.estados_excluidos)
        query = query.filter(~MaestroDianVsErp.estado_aprobacion.in_(estados))
    
    # 3. ⭐ ORDENAR: Más días arriba (más antiguo), menos días abajo (más reciente)
    query = query.order_by(MaestroDianVsErp.dias_desde_emision.desc())
    
    documentos = query.all()
    
    # 4. Agrupar por NIT
    docs_por_nit = {}
    for doc in documentos:
        nit = doc.nit_emisor
        if nit not in docs_por_nit:
            docs_por_nit[nit] = []
        docs_por_nit[nit].append(doc)
    
    # 5. Buscar usuarios asignados por NIT
    docs_por_usuario = {}
    for nit, docs in docs_por_nit.items():
        query_usuarios = """
            SELECT correo, nombres, apellidos 
            FROM usuarios_asignados 
            WHERE nit = :nit AND activo = true
        """
        usuarios = db.session.execute(db.text(query_usuarios), {'nit': nit}).fetchall()
        
        for usuario in usuarios:
            email = usuario[0]
            if email not in docs_por_usuario:
                docs_por_usuario[email] = []
            docs_por_usuario[email].extend(docs)
    
    # 6. Enviar emails consolidados
    for email, docs in docs_por_usuario.items():
        self._enviar_email_consolidado(
            destinatario=email,
            asunto=f"⏰ Documentos pendientes - {len(docs)} facturas",
            documentos=docs,
            tipo='PENDIENTES_DIAS',
            dias_min=config.dias_minimos
        )
```

##### 4. `_enviar_email_consolidado(destinatario, asunto, documentos, tipo, **kwargs)`
**Propósito:** Envía email con lista de documentos (HTML + Excel si > 50).

**Características:**
```python
def _enviar_email_consolidado(self, destinatario, asunto, documentos, tipo, **kwargs):
    total_docs = len(documentos)
    
    # ⭐ LIMITAR HTML A 50 DOCUMENTOS
    docs_para_html = documentos[:50] if total_docs > 50 else documentos
    
    # Generar HTML (con advertencia si > 50)
    html = self._generar_html_email(docs_para_html, tipo, total_documentos=total_docs, **kwargs)
    
    # Crear mensaje
    msg = MIMEMultipart('mixed')  # 'mixed' para soportar adjuntos
    msg['From'] = self.smtp_config['username']
    msg['To'] = destinatario
    msg['Subject'] = asunto
    
    # Agregar HTML
    msg_html = MIMEMultipart('alternative')
    msg_html.attach(MIMEText(html, 'html'))
    msg.attach(msg_html)
    
    # ⭐ SI HAY MÁS DE 50 DOCUMENTOS, GENERAR EXCEL ADJUNTO
    if total_docs > 50:
        excel_content = self._generar_excel_documentos(documentos, tipo, **kwargs)
        from email.mime.application import MIMEApplication
        excel_adjunto = MIMEApplication(excel_content, _subtype='xlsx')
        fecha_archivo = datetime.now().strftime('%Y%m%d_%H%M%S')
        excel_adjunto.add_header('Content-Disposition', 'attachment', 
                                filename=f'Documentos_Pendientes_{fecha_archivo}.xlsx')
        msg.attach(excel_adjunto)
        logger.info(f"   📎 Excel adjunto generado con {total_docs} documentos")
    
    # Enviar según configuración (SSL puerto 465 o TLS puerto 587)
    if self.smtp_config['use_ssl']:
        with smtplib.SMTP_SSL(self.smtp_config['server'], self.smtp_config['port']) as server:
            server.login(self.smtp_config['username'], self.smtp_config['password'])
            server.send_message(msg)
    else:
        with smtplib.SMTP(self.smtp_config['server'], self.smtp_config['port']) as server:
            if self.smtp_config['use_tls']:
                server.starttls()
            server.login(self.smtp_config['username'], self.smtp_config['password'])
            server.send_message(msg)
```

##### 5. `_generar_html_email(documentos, tipo, **kwargs)`
**Propósito:** Genera HTML profesional del email.

**Características:**
- Diseño responsivo con estilos inline
- Tabla con documentos (máximo 50 en HTML)
- ⚠️ Advertencia amarilla si hay más de 50 totales
- Resumen con total de documentos y valor
- Links a DIAN para ver documentos
- Footer corporativo

**Advertencia cuando > 50 documentos:**
```html
<div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
    <strong>⚠️ Se muestran los primeros 50 documentos de {total_documentos} totales.</strong><br>
    📎 Consulte el archivo Excel adjunto para ver el listado completo.
</div>
```

##### 6. `_generar_excel_documentos(documentos, tipo, **kwargs)`
**Propósito:** Genera Excel profesional con TODOS los documentos.

**Características:**
```python
def _generar_excel_documentos(self, documentos, tipo, **kwargs):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from io import BytesIO
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Documentos Pendientes"
    
    # ⭐ ESTILOS CORPORATIVOS
    header_fill = PatternFill(start_color="00C875", end_color="00C875", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    
    # Encabezados
    encabezados = ['#', 'NIT', 'Proveedor', 'Factura', 'Fecha Emisión', 
                   'Valor', 'Días Pendientes', 'Estado', 'CUFE']
    
    # Datos con hipervínculos en CUFE
    for i, doc in enumerate(documentos, 1):
        cufe = doc.cufe or ''
        
        # ... agregar datos ...
        
        # ⭐ COLUMNA CUFE CON HIPERVÍNCULO
        if cufe:
            cell = ws.cell(row=i+1, column=9)
            cell.value = cufe
            cell.hyperlink = f"https://catalogo-vpfe.dian.gov.co/User/SearchDocument?DocumentKey={cufe}"
            cell.style = "Hyperlink"  # Azul con subrayado
    
    # Anchos de columna optimizados
    ws.column_dimensions['A'].width = 5   # #
    ws.column_dimensions['B'].width = 12  # NIT
    ws.column_dimensions['C'].width = 35  # Proveedor
    ws.column_dimensions['D'].width = 15  # Factura
    ws.column_dimensions['E'].width = 12  # Fecha
    ws.column_dimensions['F'].width = 15  # Valor
    ws.column_dimensions['G'].width = 12  # Días
    ws.column_dimensions['H'].width = 15  # Estado
    ws.column_dimensions['I'].width = 60  # CUFE (con hipervínculo)
    
    # Fila de totales
    total_row = len(documentos) + 2
    ws.cell(row=total_row, column=5).value = "TOTAL:"
    ws.cell(row=total_row, column=6).value = sum(float(doc.valor or 0) for doc in documentos)
    ws.cell(row=total_row, column=6).number_format = '$#,##0'
    
    # Auto filtro
    ws.auto_filter.ref = f"A1:I{len(documentos) + 1}"
    
    # Retornar bytes
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output.getvalue()
```

---

## 🔄 FLUJOS DE TRABAJO

### Flujo 1: Envío Programado Automático

```mermaid
graph TD
    A[Scheduler iniciado] --> B[Espera hora configurada]
    B --> C{Hora programada?}
    C -->|No| B
    C -->|Sí| D[ejecutar_envio_programado]
    D --> E[Consultar documentos con filtros]
    E --> F[Ordenar por días DESC]
    F --> G[Agrupar por NIT]
    G --> H[Buscar usuarios por NIT]
    H --> I{Hay documentos?}
    I -->|No| J[Registrar: 0 emails enviados]
    I -->|Sí| K{Total > 50?}
    K -->|No| L[Generar HTML completo]
    K -->|Sí| M[Generar HTML primeros 50]
    M --> N[Generar Excel con todos]
    L --> O[Enviar email]
    N --> O
    O --> P[Registrar en historial]
    P --> Q[Calcular próxima ejecución]
```

### Flujo 2: Envío Manual desde Interfaz

```
1. Usuario ingresa a /dian_vs_erp/configuracion
2. Ve lista de envíos programados
3. Click en botón "Ejecutar" de un envío
4. POST /dian_vs_erp/api/config/envios/{id}/ejecutar
5. Sistema crea thread para ejecutar en background
6. Respuesta inmediata: "Ejecución iniciada. Revise el historial..."
7. Thread ejecuta: scheduler.ejecutar_envio_programado(id)
8. Logs en consola del servidor
9. Registro en historial_envios_dian_vs_erp
```

### Flujo 3: Configuración de Nuevo Envío

```
1. Usuario ingresa a /dian_vs_erp/configuracion
2. Click en "Nueva Configuración"
3. Llena formulario:
   - Nombre del envío
   - Tipo (Pendientes días / Crédito sin acuses)
   - Días mínimos
   - Estados a excluir
   - Frecuencia (Diario / Semanal)
   - Hora de envío
4. Click "Guardar"
5. POST /dian_vs_erp/api/config/envios (CREATE)
6. Sistema valida datos
7. Guarda en tabla envios_programados_dian_vs_erp
8. Reinicia scheduler para aplicar cambios
9. Nuevo job aparece en lista
```

---

## ⚙️ CONFIGURACIÓN Y USO

### Variables de Entorno Requeridas

**Archivo:** `.env`

```env
# Base de datos PostgreSQL
DATABASE_URL=postgresql://gestor_user:password@localhost:5432/gestor_documental

# Email SMTP (Gmail)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=465
MAIL_USE_SSL=True
MAIL_USE_TLS=False
MAIL_USERNAME=gestordocumentalsc01@gmail.com
MAIL_PASSWORD=urjrkjlogcfdtynq  # App Password (2FA habilitado)
MAIL_DEFAULT_SENDER=gestordocumentalsc01@gmail.com
```

### Instalación de Dependencias

```bash
# Activar virtualenv
.\.venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt

# Dependencias específicas del módulo:
# - Flask==3.0.0
# - Flask-Mail==0.9.1
# - APScheduler==3.10.4
# - openpyxl==3.1.2
# - psycopg2-binary==2.9.9
# - SQLAlchemy==2.0.23
```

### Inicialización del Sistema

**En `app.py`:**

```python
# Importar scheduler
from modules.dian_vs_erp.scheduler_envios import iniciar_scheduler_dian_vs_erp

# Iniciar scheduler al arrancar app (después de registrar blueprints)
if __name__ == '__main__':
    with app.app_context():
        scheduler_dian_vs_erp_global = iniciar_scheduler_dian_vs_erp(app)
    
    app.run(host='0.0.0.0', port=8099, debug=True)
```

### Uso desde Interfaz Web

#### 1. Acceder al Módulo
```
URL: http://localhost:8099/dian_vs_erp/configuracion
```

#### 2. Pestaña "Envíos Programados"
- Ver lista de envíos configurados
- Ver estado (Activo/Inactivo)
- Ver próxima ejecución
- Botón "Ejecutar" para envío manual inmediato
- Botón "Editar" para modificar configuración
- Botón "Eliminar" para borrar envío

#### 3. Nueva Configuración
**Ejemplo: Alerta documentos sin causar > 5 días**

```json
{
  "nombre": "Alerta sin causar 5 dias",
  "tipo_envio": "PENDIENTES_DIAS",
  "dias_minimos": 5,
  "estados_excluidos": ["Causada"],
  "frecuencia": "DIARIO",
  "hora_envio": "08:00",
  "activo": true
}
```

**Significado:**
- Enviar alerta diaria a las 08:00 AM
- Incluir documentos con 5 o más días de antigüedad
- Excluir documentos ya causados
- Enviar solo a usuarios con documentos pendientes

#### 4. Gestión de Usuarios por NIT

**URL:** `/dian_vs_erp/configuracion` → Pestaña "Usuarios por NIT"

**Agregar usuario:**
1. Click "Agregar Usuario"
2. Ingresar NIT (autocomplete busca razón social)
3. Ingresar nombres, apellidos, correo
4. Seleccionar tipo: APROBADOR o SOLICITANTE
5. Marcar "Activo"
6. Guardar

**Ejemplo:**
```
NIT: 805013653
Razón Social: LA GALERIA Y CIA SAS (autocomplete)
Nombres: RICARDO
Apellidos: RIASCOS BURGOS
Correo: ricardoriascos07@gmail.com
Tipo: APROBADOR
Activo: ✓
```

---

## 📊 LOGS Y AUDITORÍA

### Logs del Scheduler

**Ubicación:** `logs/scheduler_dian_vs_erp.log`

**Ejemplo de ejecución exitosa:**
```
2025-12-26 20:55:03 - INFO - 🚀 Iniciando envío programado ID=6
2025-12-26 20:55:03 - INFO - 📧 Email enviado a ricardoriascos07@gmail.com
2025-12-26 20:55:03 - INFO -    ✅ Email enviado a ricardoriascos07@gmail.com (139 docs)
2025-12-26 20:55:03 - INFO -    📎 Excel adjunto generado con 139 documentos
2025-12-26 20:55:30 - INFO - ✅ Envío programado ID=6 completado en 27.04s
2025-12-26 20:55:30 - INFO -    📧 Emails enviados: 1
2025-12-26 20:55:30 - INFO -    📄 Documentos incluidos: 139
```

**Ejemplo de error:**
```
2025-12-26 21:00:15 - ERROR - ❌ Error en _procesar_pendientes_dias: SMTP authentication failed
2025-12-26 21:00:15 - INFO - ✅ Envío programado ID=3 completado en 0.05s
2025-12-26 21:00:15 - INFO -    📧 Emails enviados: 0
2025-12-26 21:00:15 - INFO -    📄 Documentos incluidos: 0
```

### Tabla de Historial

**Consulta SQL para ver últimos 10 envíos:**
```sql
SELECT 
    h.id,
    e.nombre AS envio_nombre,
    h.fecha_ejecucion,
    h.estado,
    h.docs_procesados,
    h.emails_enviados,
    h.tiempo_ejecucion
FROM historial_envios_dian_vs_erp h
JOIN envios_programados_dian_vs_erp e ON h.envio_programado_id = e.id
ORDER BY h.fecha_ejecucion DESC
LIMIT 10;
```

---

## 🔧 TROUBLESHOOTING

### Problema 1: No se envían correos

**Síntoma:**
```
INFO: ✅ Envío programado ID=6 completado en 27.04s
INFO:    📧 Emails enviados: 0
INFO:    📄 Documentos incluidos: 0
```

**Posibles causas:**
1. **Tabla `usuarios_asignados` vacía** → Agregar usuarios por NIT
2. **Usuarios inactivos** → Verificar campo `activo = true`
3. **NIT no coincide** → Verificar que `nit` en usuarios = `nit_emisor` en documentos
4. **No hay documentos que cumplan criterios** → Revisar filtros de configuración

**Solución:**
```sql
-- Verificar usuarios activos
SELECT nit, correo, nombres, apellidos, activo 
FROM usuarios_asignados 
WHERE activo = true;

-- Si está vacío, agregar usuario
INSERT INTO usuarios_asignados (nit, nombres, apellidos, correo, tipo_usuario, activo)
VALUES ('805013653', 'RICARDO', 'RIASCOS BURGOS', 'ricardoriascos07@gmail.com', 'APROBADOR', true);
```

### Problema 2: Error SMTP

**Síntoma:**
```
ERROR: SMTP authentication failed
ERROR: Connection refused (port 465)
```

**Soluciones:**
1. **Gmail:** Verificar App Password (no usar contraseña normal)
2. **Puerto:** Verificar puerto correcto (465 SSL o 587 TLS)
3. **Variables:** Verificar `.env` tiene `MAIL_USERNAME` y `MAIL_PASSWORD`
4. **Firewall:** Verificar puerto 465/587 no está bloqueado

**Probar configuración:**
```python
python probar_envio_correo.py
```

### Problema 3: Excel no se genera

**Síntoma:**
```
ERROR: openpyxl requerido para generar Excel
```

**Solución:**
```bash
pip install openpyxl==3.1.2
```

### Problema 4: Scheduler no inicia

**Síntoma:**
```
ERROR: cannot import name 'scheduler_dian_vs_erp_global'
```

**Solución:**
Verificar en `app.py`:
```python
from modules.dian_vs_erp.scheduler_envios import iniciar_scheduler_dian_vs_erp

# Al final del archivo, en if __name__ == '__main__':
with app.app_context():
    scheduler_dian_vs_erp_global = iniciar_scheduler_dian_vs_erp(app)
```

### Problema 5: Hipervínculos en Excel no funcionan

**Síntoma:** Al hacer click en CUFE del Excel, no abre la DIAN.

**Solución verificada:**
```python
# ✅ URL CORRECTA (funciona)
url = f"https://catalogo-vpfe.dian.gov.co/User/SearchDocument?DocumentKey={cufe}"

# ❌ URL INCORRECTA (no funciona)
url = f"https://catalogo-vpfe-hab.dian.gov.co/document/searchqr?documentkey={cufe}"
```

---

## 📈 MÉTRICAS DE RENDIMIENTO

### Tiempos Promedio
- **Consulta de documentos:** < 1 segundo
- **Generación HTML:** < 0.5 segundos
- **Generación Excel (139 docs):** 1-2 segundos
- **Envío SMTP:** 3-5 segundos por email
- **Total (139 docs, 1 email):** 27 segundos

### Límites del Sistema
- **Documentos en HTML:** Máximo 50 (por peso del email)
- **Documentos en Excel:** Ilimitado (probado hasta 1000+)
- **Tamaño archivo Excel:** ~50 KB por cada 100 documentos
- **Usuarios por NIT:** Ilimitado
- **Envíos programados:** Ilimitado
- **Emails simultáneos:** Depende de límite SMTP (Gmail: 500/día)

---

## 🎯 PRÓXIMAS MEJORAS (ROADMAP)

### Corto Plazo (1-2 semanas)
- [ ] Dashboard de estadísticas de envíos
- [ ] Previsualización de email antes de enviar
- [ ] Exportar historial a Excel
- [ ] Notificaciones push en interfaz

### Mediano Plazo (1-3 meses)
- [ ] Plantillas personalizables de email
- [ ] Envíos a múltiples destinatarios con CC/BCC
- [ ] Integración con WhatsApp Business
- [ ] Reportes automáticos mensuales

### Largo Plazo (3-6 meses)
- [ ] Machine Learning para predecir documentos problemáticos
- [ ] Integración directa con API DIAN
- [ ] App móvil para recibir alertas
- [ ] Sistema de recordatorios escalonados

---

## 📞 SOPORTE Y CONTACTO

**Desarrollador:** Ricardo Riascos  
**Email:** ricardoriascos07@gmail.com  
**Empresa:** Supertiendas Cañaveral  
**Versión del Sistema:** 1.0.0 (Diciembre 2025)  
**Estado:** ✅ PRODUCTIVO Y FUNCIONAL

---

## 📝 NOTAS FINALES

Este módulo ha sido completamente implementado y probado en ambiente productivo desde Diciembre 26, 2025. Todas las funcionalidades documentadas aquí están operativas y en uso.

**Últimas actualizaciones:**
- ✅ 26/12/2025: Implementado ordenamiento por días (más antiguo primero)
- ✅ 26/12/2025: Implementado límite de 50 docs en HTML + Excel adjunto
- ✅ 26/12/2025: Implementado hipervínculos en Excel a DIAN (URL correcta)
- ✅ 26/12/2025: Corrección de tabla de usuarios a `usuarios_asignados`
- ✅ 26/12/2025: Sistema de envíos automáticos completamente funcional

---

**FIN DEL DOCUMENTO**
